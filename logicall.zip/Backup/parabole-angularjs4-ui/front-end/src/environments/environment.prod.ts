export const environment = {
  production: true,
  BASE_URL: 'http://testcojun.eastus.cloudapp.azure.com:50001/api/v1/'
};

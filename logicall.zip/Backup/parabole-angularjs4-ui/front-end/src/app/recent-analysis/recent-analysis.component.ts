import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'recent-analysis',
  templateUrl: './recent-analysis.component.html',
  styleUrls: ['./recent-analysis.component.css']
})
export class RecentAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

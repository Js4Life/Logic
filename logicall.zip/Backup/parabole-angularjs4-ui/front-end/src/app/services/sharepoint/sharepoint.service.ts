import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {BaseHttpService} from "../../services/base-http.service";
import { ClientState} from '../../providers/clientstate.provider';
import {HttpVerbs} from "../../models/constants.model";
import { Observable} from 'rxjs/Rx';
import { ResponseModel} from '../../models/response.model';

import {SharepointLogin} from "../../models/sharepointLogin.model";


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

declare var stringformat : any;

@Injectable()
export class SharepointService {

  nodeServerURL : string = 'http://localhost:5555';

    private actionUrl: string = 'http://localhost:5555/login';
    private headers: Headers;
    private options: RequestOptions;
    

  constructor(appState: ClientState, private http: Http ){
        //super(appState, http);
        

      }


     loginSharepoint(form1Data : SharepointLogin){
    var loginUrl = this.nodeServerURL+ '/login';

    this.headers = new Headers();
    //this.headers.append('Content-Type', 'application/json');
    this.headers.append('Content-Type', 'application/x-www-form-urlencoded');
    // this.headers.append('Accept', 'application/json');
    //this.headers.append('Access-Control-Allow-Headers', 'Content-Type, X-XSRF-TOKEN');
    this.options = new RequestOptions({ headers: this.headers });

    //  return this.http.post(this.actionUrl, formData, this.options).map(data => data.json())
    //                     .catch((error: any) => Observable.throw(error || 'Server error'));

           var resObservable : Observable<ResponseModel>;
           let httpResponse : ResponseModel  = new ResponseModel();
           var formData= 'username=' + form1Data.username + '&'
                          +   'password=' + form1Data.password + '&'
                          +   'folder=' + form1Data.folder + '&'
                          +   'dirRid=' + form1Data.dirRid + '&'
                          +   'sitename=' + form1Data.sitename ;
           resObservable = this.http.post(loginUrl, formData, this.options).map(data => data.json())
                        .catch((error: any) => Observable.throw(error || 'Server error'));

          return resObservable
          .map(data=>data)
          .toPromise()
          .then(data => {
              httpResponse.data = data;
              httpResponse.status = true;
              return httpResponse;
          })
          .catch((error: any) => {
              //httpResponse = new ResponseModel();
              httpResponse.status = false;
              httpResponse.code = error.status;
              return httpResponse;
          });
  }


  getSharePointFolder(folderPath){
    var folderUrl = this.nodeServerURL+'/folder';

    var resObservable : any;
    var httpResponseErr : ResponseModel ;
    var payload = {
                'folderPath' : folderPath,
                'sharepointSite': sessionStorage.sharepointSite,
                'param1' : sessionStorage.param1,
                'param2' : sessionStorage.param2
            }
    resObservable = this.http.post(folderUrl, payload)
                        //.map(x => console.log(x))
                        .map(x => x)
                        .catch((error: any) => Observable.throw(error || 'Server error'));

          return resObservable
          .map(data=>data)
          .toPromise()
          .then(data => {
              return data._body;
          })
          .catch((error: any) => {
              httpResponseErr = new ResponseModel();
              httpResponseErr.status = false;
              httpResponseErr.code = error.status;
              return httpResponseErr;
          });
  }

  uploadSelectedFiles(filePathArr){
    var resObservable : Observable<ResponseModel>;
    let httpResponse : ResponseModel  = new ResponseModel();
    var postUrl = this.nodeServerURL+'/file';
    var payload = {
            'filePathArr' : filePathArr,
            'sharepointSite': sessionStorage.sharepointSite,
            'param1' : sessionStorage.param1,
            'param2' : sessionStorage.param2
    };
    return this.http.post(postUrl, payload)
                //.map(x => console.log(x))
                .map(x => x)
                .toPromise()
                .catch((error: any) => Observable.throw(error || 'Server error'));
  }

  downloadFile(filePath, fileName){
    var resObservable : Observable<ResponseModel>;
    let httpResponse : ResponseModel  = new ResponseModel();
    var httpResponseErr : ResponseModel ;
    var postUrl = this.nodeServerURL+'/file';
    let uniqId = Math.round(Math.random() *1000);
    var payload = {
            'filePath' : filePath,
            'sharepointSite': sessionStorage.sharepointSite,
            'param1' : sessionStorage.param1,
            'param2' : sessionStorage.param2,
            'fileReqstId' : uniqId
        };
     return this.http.post(postUrl, payload)
                        //.map(x => console.log(x))
                        .map(x => x)
                        .toPromise()
                        .catch((error: any) => Observable.throw(error || 'Server error'));


        //   return resObservable
        //   .map(data=>data)
        //   .toPromise()
        //   .then(data => {
        //       console.log('Data from Post file :: ' + data);
        //       return data;
        //   })
        //   .catch((error: any) => {
        //       httpResponseErr = new ResponseModel();
        //       httpResponseErr.status = false;
        //       httpResponseErr.code = error.status;
        //       return httpResponseErr;
        //   });
    // return Observable.fromPromise(new Promise((resolve, reject) => {
    //     var payload = {
    //         'filePath' : filePath,
    //         'sharepointSite': sessionStorage.sharepointSite,
    //         'param1' : sessionStorage.param1,
    //         'param2' : sessionStorage.param2
    //     };
    //     var downloadUrl = this.nodeServerURL+'/file';
        
    //     let xhr = new XMLHttpRequest();
    //     xhr.open("POST", downloadUrl, true);
    //     xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    //     xhr.onreadystatechange = function () {
    //         //xhr.abort();
    //         if (xhr.readyState === 4) {
    //             if (xhr.status === 200) {
    //                 resolve(JSON.parse(xhr.response))
    //             } else {
    //                 reject(xhr.response)
    //             }
    //         }
    //     }

    //     xhr.send(JSON.stringify(payload));
        
    //     console.log('file sent.');
    // }))
    // .map(data=>data)
    // .toPromise()
    // .then(data => {
    //     httpResponse.data = data;
    //     httpResponse.status = true;
    //     return httpResponse;
    // })
    // .catch((error: any) => {
    //     //httpResponse = new ResponseModel();
    //     httpResponse.status = false;
    //     httpResponse.code = error.status;
    //     return httpResponse;
    // });

  }
  /*downloadFile(filePath, fileName){
    var downloadUrl = this.nodeServerURL+'/file';

    var resObservable : any;
    var httpResponseErr : ResponseModel ;
    var payload = {
                'filePath' : filePath,
                'sharepointSite': sessionStorage.sharepointSite,
                'param1' : sessionStorage.param1,
                'param2' : sessionStorage.param2
            }
    var req = new XMLHttpRequest();
    req.open("POST", downloadUrl, true);
    // req.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    req.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    req.responseType = "blob";
    req.onload = function (event) {
        var blob = req.response;
        //alert(blob.size);
        var link = document.createElement('a');
        var url = window.URL.createObjectURL(blob);
        link.href = url ;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        setTimeout(function(){
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);  
        }, 100); 
    };
    req.send(JSON.stringify(payload));
    req = null;
  }*/
}

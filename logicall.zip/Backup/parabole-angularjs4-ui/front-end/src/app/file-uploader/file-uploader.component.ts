import { Component, OnInit, DoCheck } from '@angular/core';
import { ClientState } from '../providers/clientstate.provider';

@Component({
  selector: 'app-file-uploader',
  templateUrl: './file-uploader.component.html',
  styleUrls: ['./file-uploader.component.css']
})
export class FileUploaderComponent implements OnInit {

  currentState : String='';
  progress : number=0;
  count : number=0;
  
  constructor(private clientState:ClientState) { }

  stateController(){
    if(this.count==0){
      this.currentState='Loading';
      this.progress=10;
    }
    else if(this.count==1){
      this.currentState='Parsing';
      this.progress=30;
    }
    else if(this.count==2){
      this.currentState='Term extraction';
      this.progress=50;
    }
    else if(this.count==3){
      this.currentState='Context analysis';
      this.progress=60;
    }
    else if(this.count==4){
      this.currentState='DB update';
      this.progress=80;
    }
    if(this.count!=4){
      setTimeout(()=>{ this.count=this.count+1;
        this.stateController(); 
      }, 20000); 
    }
  }

  onInitialize(){}

  ngOnInit() {
    this.count=0;
    this.stateController();
  }

  ngDoCheck(){
    if(this.clientState.isNewFileUploading){
      this.clientState.isNewFileUploading=false;
      this.ngOnInit();
    }
  }
}

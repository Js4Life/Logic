export class ChecklistFiles {
  id: number;
  name: string;
  status: string;
  createdBy: string;
  createdAt: any;
}
import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { UtilsService } from '../../services/utils.service';
import {SharepointService} from '../../services/sharepoint/sharepoint.service';
import {SharepointLogin} from '../../models/sharepointLogin.model';
import { ClientState } from '../../providers/clientstate.provider';

declare var $ ;
declare var _ ;

export interface modalRequisiteData{
  dirRid : string;
}

export class TemplateData {
  constructor(public selectedReport_template:any) {
    
  }
} 

@Component({
  selector: 'sharepoint-modal',
  templateUrl: './sharepoint-modal.component.html',
  styleUrls: ['./sharepoint-modal.component.css']
})

  export class SharepointModalComponent extends DialogComponent<any, any> implements OnInit, modalRequisiteData{
  template:any={name:null, description:null};
  dirRid :string;
  ///////////////
    loginForm: SharepointLogin = {folder:'',password:'', sitename:'',username: '', dirRid:''};
  isLoggedIn :boolean = false;

  ///////////////
  rootFolder: any;
  folderStack = [] ;
  sharepointSite: string;
  param1 :string;
  param2 :string;
  ws : any;

  // fileTypeAssociation = {
  //   pdf: "../../assets/img/pdf.png",
  //   txt: "../../assets/img/txt.png",
  //   doc: "../../assets/img/doc.png",
  //   docx: "../../assets/img/doc.png",
  //   ppt: "../../assets/img/ppt.png",
  //   pptx: "../../assets/img/ppt.png",
  //   xls: "../../assets/img/xls.png",
  //   xlsx: "../../assets/img/xls.png"
  // }
    currentFolder: string;
    fileArray: any = [];
    folderArray:any = [];
    downloadFileArr:any=[];

  constructor(public dialogService: DialogService, private utilSvc:UtilsService, private sharepointService : SharepointService, private clientState:ClientState) { 
    super(dialogService);
  }

  // onClick(opt){
  //   switch(opt){
  //     case 'continue':
  //       this.result = true;
  //       this.validate();
  //       break;
  //     case 'cancel':
  //       this.close();
  //       break;
  //   }
  // }

  // validate(){
  //   if(this.template.name && this.template.name.trim()!=''){
  //     this.utilSvc.notifyTemplateNameModalData(this.template);
  //     this.close();
  //   }
  // }


  ngOnInit() {
    console.log(this.dirRid + " <-the dir id");
    
  }

    connect(){
    this.loginForm.dirRid = this.dirRid;
    this.sharepointService.loginSharepoint(this.loginForm)
    .then(a => {
        //this.loading = false;    
        if(a.status){
          let credentials : any = a.data ;
          sessionStorage.folder = this.loginForm.folder ;
          sessionStorage.sharepointSite = 'https://' + this.loginForm.sitename + '.sharepoint.com' ;
          sessionStorage.param1 = credentials.cookie_rtFa_FedAuth ;
          sessionStorage.param2 = credentials.digest ;

          //console.log(sessionStorage.param1 + "-----------------"+ sessionStorage.param2);
          this.isLoggedIn = true;
          this.openRootFolder();
        }
    })
  }

  openRootFolder(){
        this.rootFolder = sessionStorage.folder ;
        this.sharepointSite = sessionStorage.sharepointSite ;
        this.param1 = sessionStorage.param1 ;
        this.param2 = sessionStorage.param2 ;
        
        //var folderPath = this.getPathFromFolderStack() + sessionStorage.folder;
        this.getSharePointFolder(this.rootFolder) ;
  }


  getSharePointFolder(folderName){
        var folderPath = this.getPathFromFolderStack() + folderName ;

        this.sharepointService.getSharePointFolder(folderPath)
        .then(a=>{
          //console.log(a);
          this.currentFolder = folderName;
          this.folderStack.push(folderName) ;
          this.processFolderXML(a) ;
        })
  }

  getPathFromFolderStack(){
    var path = "" ;
      for (var i= 0 ; i < this.folderStack.length; i++ ){
          path += this.folderStack[i] + "/" ;
      }
      return path ;
  }

  processFolderXML(folderXML){
    //console.log("||===========out===========|| "+a);
    var outerThis = this;

    ////////////////////
    // $(folderXML).find('entry').each(function(i,j)
		//     {
    //       var category = $(j).find("category").attr("term") ;
		//     	var filePath = $(j).find("id").text() ;
    //       var fileLink = filePath + "/$value" ; 

    //       if ( category == "SP.File"){
    //         console.log();
    //         var fileName =  filePath.substring(filePath.lastIndexOf("/")+1, filePath.lastIndexOf("')"));
    //         var ext = outerThis.getExtensionFromFileName(fileName) ;
    //         var fileIcon = "../../assets/img/file.png" ;
    //         if ( ext != undefined)
    //                     fileIcon = outerThis.fileTypeAssociation[ext] ;
    //         var fileLink = encodeURI ( outerThis.sharepointSite + '/' + outerThis.getPathFromFolderStack() + fileName ) ;
    //         // var listItemFile = '<li class="file" data-icon="false"><input class="mycheckbox" type="checkbox" /><a class="filelink" href="javascript:downloadMe(\'' + fileName +'\')" filename="' + fileName +'"><img src="' + fileIcon +'" class="ui-li-icon ui-corner-none">'+ fileName +'</a></li>'
    //         var listItemFile = '<div class="file" data-icon="false"><input class="mycheckbox" type="checkbox" /><span class="filelink"  filename="' + fileName +'"><img src="' + fileIcon +'" class="ui-li-icon ui-corner-none">'+ fileName +'</span></div>'
		// 			  $('#folderList').append(listItemFile);
    //       }

    //       else if ( category == "SP.Folder"){
    //         var subFolderName =  filePath.substring(filePath.lastIndexOf("/")+1, filePath.lastIndexOf("')"));
    //         // var listItemFolder = '<li class="folder" data-icon="carat-r"><input class="mycheckbox" type="checkbox" style="visibility:hidden" /><a href="javascript:getSharePointFolder(\'' + subFolderName + '\')"><img src="../../assets/img/directory.png"  class="ui-li-icon ui-corner-none">' + subFolderName + '</a></li>' ;
    //         var listItemFolder = '<div class="folder" data-icon="carat-r"><input class="mycheckbox" type="checkbox" style="visibility:hidden" /><span (click)="outerThis.getSharePointFolder(\'' + subFolderName + '\')"><img src="../../assets/img/directory.png"  class="ui-li-icon ui-corner-none">' + subFolderName + '</span></div>' ;
    //         $('#folderList').append(listItemFolder);
    //       }
    //     }
    // )
        ///////////////////
        this.folderArray=[];
        this.fileArray = [];
        this.downloadFileArr = [];

        $(folderXML).find('entry').each(function(i,j)
          {
            var category = $(j).find("category").attr("term") ;
            var filePath = $(j).find("id").text() ;
            var fileLink = filePath + "/$value" ;

            if ( category == "SP.File"){
              var fileName =  filePath.substring(filePath.lastIndexOf("/")+1, filePath.lastIndexOf("')"));
              var ext = outerThis.getExtensionFromFileName(fileName) ;
              var fileLink = encodeURI ( outerThis.sharepointSite + '/' + outerThis.getPathFromFolderStack() + fileName ) ;
              
              outerThis.fileArray.push({"fileName":fileName,"ext":ext,"fileLink":fileLink, "isSelected": false});
            }
            else if ( category == "SP.Folder"){
              var subFolderName =  filePath.substring(filePath.lastIndexOf("/")+1, filePath.lastIndexOf("')"));
              outerThis.folderArray.push({"subFolderName":subFolderName});
            }
          })
        
      
      ////////////////////////

  }

  onClick(obj,e){
    console.log(obj);
    //console.log(e);
    if(obj.subFolderName){
      this.getSharePointFolder(obj.subFolderName)
    }
    else if(obj.fileName){
      if(! _.contains(this.downloadFileArr,obj ))
        this.downloadFileArr.push(obj);
      else{
        this.downloadFileArr = _.without(this.downloadFileArr, _.findWhere(this.downloadFileArr, {
            fileName: obj.fileName
          }));  
      }
      console.log(this.downloadFileArr);
    }
  }
  
  goBack()
  {
      if ( this.folderStack.length >=2)
      {
          // get rid of current folder
          this.folderStack.pop() ;
          // get the folder you already visited and fetch it again
          var folderName = this.folderStack.pop() ;
          this.getSharePointFolder(folderName) ;
      }
  }

  getExtensionFromFileName(fileName){
      var re = /(?:\.([^.]+))?$/;
      return re.exec(fileName)[1] ;
  }

  // downloadSelected(){
  //   console.log(this.downloadFileArr);
  //     this.downloadFileArr.forEach(element => {
  //       this.downloadFile(element.fileName);
  //     });
    
  // }
    uploadSelectedFiles(){
    console.log(this.downloadFileArr);
    let filePathArr:any = [];
    var count=0;
      this.downloadFileArr.forEach(element => {
        //this.downloadFile(element.fileName);
        var filePath = this.getPathFromFolderStack() + element.fileName ;
        filePathArr.push(filePath);
        
      });
      this.initWebSocket('ws:localhost:4444');
      this.clientState.uploadFilePopUp=true;
      this.clientState.currentUploadingFileNo=count+1;
      this.clientState.noOfUploadingFiles=filePathArr.length;
      this.clientState.uploadingFile=this.downloadFileArr[count].fileName;
      
      this.sharepointService.uploadSelectedFiles(filePathArr).then(a=>{
        console.log('--------------------------------------------');
        console.log(a);
        this.ws.onmessage = (e) => {
          console.log('response from web socket');          
          console.log(e);
          if(this.clientState.noOfUploadingFiles==count+1){
            count++;
            this.clientState.uploadFileReady=true;
            setTimeout(()=>{ this.clientState.uploadFileReady=false;
              this.clientState.uploadFilePopUp=false; 
              this.clientState.uploadingFile=''; 
            }, 4000);
          }
          else{
            count++;
            this.clientState.uploadFileReady=true;
            setTimeout(()=>{ this.clientState.uploadFileReady=false; 
            }, 2000);
            this.clientState.currentUploadingFileNo=count+1;
            this.clientState.uploadingFile=this.downloadFileArr[count].fileName;
            this.clientState.isNewFileUploading=true;
          }
        };
      }

      )
    this.close();
  }

  initWebSocket(url){
    this.ws=new WebSocket(url);
    // setTimeout(()=>{
    let obj={'type':'join', 'value':this.loginForm.username};
    let stringObj = JSON.stringify(obj);
    this.ws.send(stringObj);
    this.ws.onmessage = (e) => {
      console.log('response from web socket');          
      console.log(e);
    };
  // }, 4000);
  }

  downloadFile(fileName){
    var filePath = this.getPathFromFolderStack() + fileName ;
    this.sharepointService.downloadFile(filePath, fileName)
    .then(
      a=>{
        console.log(a);
      }
    );
    filePath = fileName = null;
     this.close();
  }

  cancel(){
    this.fileArray = [];
    this.folderArray = [];
    this.downloadFileArr=[];
    this.isLoggedIn = false;
    this.close();
  }
}

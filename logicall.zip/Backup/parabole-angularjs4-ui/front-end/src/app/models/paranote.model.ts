import {BaseDataVM} from "../models/basedata.model"

export class ParaNoteVM extends BaseDataVM{
    isPrivate : boolean
}
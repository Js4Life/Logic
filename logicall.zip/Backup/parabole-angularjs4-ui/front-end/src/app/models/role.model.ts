import {BaseDataVM} from "../models/basedata.model"

export class RoleVM extends BaseDataVM{
    roleId : string
}
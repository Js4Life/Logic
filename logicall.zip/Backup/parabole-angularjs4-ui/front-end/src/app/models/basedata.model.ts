export class BaseDataVM{
    id? : string
    name? : string
}
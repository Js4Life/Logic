import {BaseDataVM} from "../models/basedata.model"
import {ContextWeightVM} from '../models/contextweight.model'

export class ParaFeedback {
    context : string
    feedback : string
}
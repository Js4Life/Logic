import {BaseDataVM} from "../models/basedata.model"
import {ContextWeightVM} from '../models/contextweight.model'

export class ContextVM extends BaseDataVM{
    contextURI : string
    color : any    
}
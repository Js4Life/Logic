import {BaseDataVM} from "../models/basedata.model"

export class SharepointLogin {
    username : string;
    password :string;
    folder : string;
    sitename : string;
    dirRid : string;
}
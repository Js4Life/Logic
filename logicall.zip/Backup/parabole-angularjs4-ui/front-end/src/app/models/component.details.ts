import {BaseDataVM} from "../models/basedata.model"

export class ComponentsVM extends BaseDataVM {
  dimensionId: number;
  contextIds : Array<any>;
}

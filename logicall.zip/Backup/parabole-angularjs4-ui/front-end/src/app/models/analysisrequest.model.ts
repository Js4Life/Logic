import {BaseDataVM} from "../models/basedata.model"

export class AnalysisRequestVM extends BaseDataVM{
    contextRids : Array<string>
    docRids : Array<string>
}
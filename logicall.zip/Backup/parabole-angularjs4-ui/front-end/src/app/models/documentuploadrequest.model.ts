export class DocumentUploadRquestVM {
    // regulationId : string
    folderId : string
    file : FormData
    // isExternal : boolean

}
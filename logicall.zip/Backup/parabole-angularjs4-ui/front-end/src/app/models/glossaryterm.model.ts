import {BaseDataVM} from "../models/basedata.model"

export class GlossaryTermVM extends BaseDataVM{
    isGlobalIdReady:boolean
    isAbstract:boolean
}
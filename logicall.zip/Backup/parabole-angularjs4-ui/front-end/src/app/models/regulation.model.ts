import {BaseDataVM} from "../models/basedata.model"

export class RegulationVM extends BaseDataVM {
    regulationType : string
}
# README #

README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

This is for UI implementation of Angular JS 4.
This is based on the new UX

### How do I get set up? ###


### Contribution guidelines ###


### Who do I talk to? ###


import os
import logging
import platform
import sys

logging.basicConfig(level=logging.INFO,format='%(asctime)s:%(levelname)s:%(message)s')

def creating_directory(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
            logging.info("{} has been created".format(directory))
        else:
            logging.info("{} was already present".format(directory))
    except Exception as e:
        logging.error(e.message)

operating_system = platform.system()
logging.info("Os is {}".format(operating_system))
if operating_system == "Windows":
    file_name = "FoldersToCreateWindows.txt"
elif operating_system == "Linux":
    file_name = "FoldersToCreateLinux.txt"
else:
    logging.info("Sorry we do not handle that Operating system yet")
    sys.exit(1)


with open(file_name, "r") as f:
    all_content = f.read()
    logging.info("File has been read")

folders_to_create = all_content.split("\n")
logging.info("List of directories to create has been genrated")

#Creating the parent directories first
for directory in folders_to_create:
    creating_directory(directory)


#Adding the script to download nltk data if not present
import nltk
nltk.download('all')


#adding platform and bit version of python present
print("Python present is {}".format(platform.architecture()))





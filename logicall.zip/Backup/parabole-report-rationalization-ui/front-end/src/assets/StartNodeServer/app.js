var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');
var sleep = require('system-sleep');
// var sleep = require('sleep');

console.log("logging...");
app.listen(8082, ()=>{
    console.log("running");
});
console.log("logging agn...");

function handler (req, res) {
  fs.readFile(__dirname + '/index.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}


call();
// call2();
call();
// call2();
call();

arr1 = [{
    "filename":1,
    "status":"Uploading Reports",
    "percentage":"10"
}

]

arr2 = [{
    "filename":2,
    "status":"Uploading Reports",
    "percentage":"30"
}]

arr3=[{
    "filename":3,
    "status":"Uploading Reports",
    "percentage":"50"
}]

arr4 = [{
    "filename":3,
    "status":"Uploading Reports",
    "percentage":"70"
}]

arr5 = [{
    "filename":3,
    "status":"Uploading Reports",
    "percentage":"90"
}]


arr6=[{
    "filename":5,
    "status":"Upload Complete",
    "percentage":"100"
}]


// {
//     "filename":2,
//     "status":"Analysing Context",
//     "percentage":"30"
// },{
//     "filename":3,
//     "status":"12 Contexts identified",
//     "percentage":"60"
// },
// {
//     "filename":4,
//     "status":"91 Terms Identified",
//     "percentage":"80"
// },
// {
//     "filename":5,
//     "status":"Ready to view",
//     "percentage":"20"
// }

function call(){
    io.on('connection', function (socket) {
        // socket.emit('news', "data");
        socket.emit('news', arr1);
        sleep(2000);
        socket.emit('news', arr2);
        sleep(2000);
        socket.emit('news', arr3);
        sleep(2000);
        socket.emit('news', arr4);
        sleep(2000);
        socket.emit('news', arr5);
        sleep(2000);
        socket.emit('news',arr6);
        sleep(2000);


    });

    io.on('disconnect', function(){
        console.log("ok");
    })

}

// function call2(){
//     io.on('connection', function (socket) {
//         socket.emit('news', "data2");
//     });

//     io.on('disconnect', function(){
//         console.log("ok");
//     })

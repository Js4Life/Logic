import { Component, OnInit } from '@angular/core';
import { DocumentSvc } from '../services/document/document.service';
import { LoaderService } from '../services/loader/loader.service';
import { AppRouteConfig } from '../app.router.config';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-file-browser',
  templateUrl: './file-browser.component.html',
  styleUrls: ['./file-browser.component.css']
})
export class FileBrowserComponent implements OnInit {
  showBar: boolean = true;
  emptyFolderCase: boolean = false;
  showModal: boolean = false;
  showPopup: boolean = false;
  initateLearning: boolean = true;
  showProgressBar: boolean = false;
  LearningProgressBar: boolean = false;
  status: any;
  reportId: any;
  uploadedDoc: FormData;
  messages = [];
  message;
  connection;
  dataa;
  uploadComplete: any;
  folderHeading: any = { name: [], reportURL: [] };
  loading = false;


  headings: any = [
    { name: 'Total Reports', value: 4870 },
    { name: 'Mapping to be Validated', value: 0 },
    { name: 'Mapping Accepted', value: 0 },
    { name: 'Mapping Rejected', value: 0 }
  ]

  folderHeading1: any = [
    { name: 'Accounting', learning: 'Never', Status: '-' },
    { name: 'Finanace', learning: 'Never', Status: '-' },
    { name: 'Product', learning: 'Never', Status: '-' },
    { name: 'Sales', learning: 'Never', Status: '-' }
  ]

  uploadFile(event: any) {
    this.loading = true;
    let file;
    this.showProgressBar = true;
    for (var i = 0; i < event.target.files.length; i++) {
      file = event.dataTransfer ? event.dataTransfer.files[i] : event.target.files[i] || event.srcElement;
      this.uploadedDoc = new FormData();
      this.uploadedDoc.append('document', file);
      this.docSvc.uploadANewDocument(this.uploadedDoc).then(data => {
        this.loading = true;
        this.uploadComplete = data['status'];
        if (this.uploadComplete) {
          this.unlinkedReports();
          $('#uploadPop').modal('show');
        }
      });
    }
    this.showBar = false;
    this.showProgressBar = false;

  }

  initiateLearning() {
    this.initateLearning = false;
    this.LearningProgressBar = true;
    this.loading = true;
    this.docSvc.learning().then(data => {
      console.log(data);
      this.status = data['status'];
      this.reportId = data['data'].triggerLearning.replace('#', '');
      this.showBar = false;
      this.loading = false;
      if (this.status) {
        $("#viewTemplate").modal('show');
      }
    })
    this.LearningProgressBar = false;
  }

  viewTemplates() {
    this.arc.gotoDashboardChild('templateList');
    this.docSvc.getTemplates(this.reportId).then(data => {
      // console.log(data);
    })
  }

  unlinkedReports() {
    this.loading = true;
    this.docSvc.getUnlinked().then(data => {
      // console.log(data);
      this.loading = false;
      this.folderHeading = data['data'].unlinked;
      this.emptyFolderCase = this.folderHeading.length;
    })
  }

  showPop() {
    this.showModal = true;

  }
  HidePopup() {
    this.showModal = false;
  }

  show() {
    this.showPopup = true;
  }

  hide() {
    this.showPopup = false;
  }


  progressBar() {
    this.connection = this.loadService.getMessages().subscribe(message => {
      this.messages.push(message);
      this.dataa = this.messages[this.messages.length - 1];
      console.log(this.messages);
    })
  }

  constructor(public docSvc: DocumentSvc, public router: Router, private arc: AppRouteConfig, private loadService: LoaderService) { }

  ngOnInit() {
    this.unlinkedReports();
  }


}

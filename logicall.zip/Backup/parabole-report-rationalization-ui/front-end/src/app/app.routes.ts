import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule} from '@angular/router';

import {AppComponent} from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { TemplateListComponent } from './template-list/template-list.component';
import { TemplateValidationComponent } from './template-validation/template-validation.component';
import { FileBrowserComponent } from './file-browser/file-browser.component';
import { SettingsComponent } from './settings/settings.component';

export const router : Routes = [
    {path:'', component: LoginComponent},
    {path:'login', component: LoginComponent},
    {path:'dashboard', component: DashboardComponent,
    children: [
            {path : 'home' , component : HomeComponent},
            {path : 'learninglibrary' , component : FileBrowserComponent},
            {path:'templateList', component:TemplateListComponent},
            {path:'settings', component:SettingsComponent},
        ]
    },
    {path:'templateValidation/:templateId', component: TemplateValidationComponent}

    // { path:'state-selections/:dataString', component: StateSelectionsComponent},
];

export const routes : ModuleWithProviders = RouterModule.forRoot(router);



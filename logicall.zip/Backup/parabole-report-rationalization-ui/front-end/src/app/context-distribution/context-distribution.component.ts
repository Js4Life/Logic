import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-context-distribution',
  templateUrl: './context-distribution.component.html',
  styleUrls: ['./context-distribution.component.css']
})
export class ContextDistributionComponent implements OnInit {

  @Input() contextList;
  @Input() templateName;
  @Input() reportName;
  
  distributionOptions:any = [
    {id:'report', name:'Report', count:0, color:'#e3eefa', isSelected:false},
    {id:'template', name:'Template', count:0, color:'#f5e1ff', isSelected:false},
    {id:'both', name:'Common to Both', count:0, color:'#b5ffc1', isSelected:true},
  ]

  constructor() { }

  ngOnInit() {
    console.log(this.contextList);
    console.log(this.templateName);
    console.log(this.reportName);
  }

}

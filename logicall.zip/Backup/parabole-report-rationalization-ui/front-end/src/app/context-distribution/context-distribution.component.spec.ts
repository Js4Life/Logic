import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContextDistributionComponent } from './context-distribution.component';

describe('ContextDistributionComponent', () => {
  let component: ContextDistributionComponent;
  let fixture: ComponentFixture<ContextDistributionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContextDistributionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContextDistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

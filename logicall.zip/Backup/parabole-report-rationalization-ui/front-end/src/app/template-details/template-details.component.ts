import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-details',
  templateUrl: './template-details.component.html',
  styleUrls: ['./template-details.component.css']
})
export class TemplateDetailsComponent implements OnInit {

  @Input() template:any;

  constructor() { }

  ngOnInit() {
  }

}

import { BaseVM } from './base.model';


export class ReportDefVM extends BaseVM{
    reportURL:string
}
import {BaseVM} from "../models/base.model"

export class RoleVM extends BaseVM{
    roleId : string
}
import {BaseVM} from "./base.model"
import {ContextWeightVM} from './contextweight.model'

export class ContextVM extends BaseVM{
    contextURI : string
    color : any    
}
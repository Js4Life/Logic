import { ReportDefVM } from './reportDef.model';

export class ReportUploadDetailsVM {
    userId : String
    uploadDate : String
    reports : Array<ReportDefVM>
}
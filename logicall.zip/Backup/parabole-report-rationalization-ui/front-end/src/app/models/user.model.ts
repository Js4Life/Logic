import {BaseVM} from "../models/base.model"
import {RoleVM} from "../models/role.model"

export class UserVM extends BaseVM{
    role : RoleVM = new RoleVM();
    lastLogin : string
    userId : string
    password : string
}
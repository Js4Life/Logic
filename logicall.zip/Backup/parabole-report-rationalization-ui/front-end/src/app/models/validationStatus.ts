export enum ValidationStatus {
    NOTSTARTED,
    INPROGRESS,
    APPROVED,
    REJECTED
}
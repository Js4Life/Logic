export class BaseVM{
    id? : string
    name? : string
}
import { ReportTemplateVM } from './reportTemplate.model';
import { ReportUploadDetailsVM } from './reportUploadDetails.model';

export class ReportAnalysisResultsVM{
    templateClusters : Array<ReportTemplateVM> 
    uploadDetails : ReportUploadDetailsVM 
}
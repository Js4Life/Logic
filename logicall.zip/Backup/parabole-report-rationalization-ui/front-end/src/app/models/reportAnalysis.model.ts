import { ValidationStatus } from './validationStatus';
import { ReportDefVM } from './reportDef.model';


export class ReportAnalysisVM{
    systemTermConfidenceLevel:number;
    systemContextConfidenceLevel:number;
    systemTermDistributionConfidenceLevel:number;
    validationStatus:ValidationStatus;
    linkedReport:ReportDefVM;
    userTermsConfidenceLevelRange:number;
    userContextConfidenceLevelRange:number;
    userRelatedTermsConfidenceLevelRange:number;
}
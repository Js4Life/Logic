export class TermDetailsVM{
    termValue : String
    importance : number
    aliases : Array<String>
    relatedTerms : Array<String>
    domain : Array<String>
    semanticRelavance : Array<String>
}
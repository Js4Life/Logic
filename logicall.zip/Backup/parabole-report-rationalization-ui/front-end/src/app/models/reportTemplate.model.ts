import { ValidationStatus } from './validationStatus';
import { ReportAnalysisVM } from './reportAnalysis.model';
import { BaseVM } from './base.model';
import { ContextWeightVM } from './contextweight.model';
import { TermDetailsVM } from './termDetails.model';

export class ReportTemplateVM extends BaseVM {

    terms: Array<TermDetailsVM>
    contexts : Array<ContextWeightVM>
    targetGeography : String
    description : String 
    validationStatus : ValidationStatus
    businessSegment : String
    linkedReports : Array<ReportAnalysisVM>

}
import { Component, OnInit,Input } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
declare var $:any;

@Component({
  selector: 'distribution-line',
  templateUrl: './distribution-line.component.html',
  styleUrls: ['./distribution-line.component.css']
})
export class DistributionLineComponent implements OnInit {

  @Input() data:any;
  edge = {
    top: true,
    bottom: true,
    left: true,
    right: true
  };
  constructor() { 
  }

  onDragBegin(e,idx){
    console.log('started output:', e);
    var o1 = document.getElementById('marker'+idx);
    var st = window.getComputedStyle(o1, null);
    var tr = st.getPropertyValue("-webkit-transform") ||
         st.getPropertyValue("-moz-transform") ||
         st.getPropertyValue("-ms-transform") ||
         st.getPropertyValue("-o-transform") ||
         st.getPropertyValue("transform") ||
         "Either no transform set, or browser doesn't do getComputedStyle";
    var style = tr;
    // var current_pull = parseInt($('.marker'+idx).css('transform').split(',')[4]);
  }
  onDragEnd(e){
    console.log('stopped output:', e);
  }

  changeWidth(){
    this.data.forEach(obj=>{
      obj.width = obj.value*100+'%';
    })
  }

  checkEdge(event) {
    this.edge = event;
    console.log('edge:', event);
  }

  changeDistribution(idx,e){
    var e = e;
  }

  ngOnInit() {
    if(this.data){
      this.changeWidth();
      // this.changeDistribution();
    }
  }

}

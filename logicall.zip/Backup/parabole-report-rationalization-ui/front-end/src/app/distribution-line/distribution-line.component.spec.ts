import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributionLineComponent } from './distribution-line.component';

describe('DistributionLineComponent', () => {
  let component: DistributionLineComponent;
  let fixture: ComponentFixture<DistributionLineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DistributionLineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DistributionLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

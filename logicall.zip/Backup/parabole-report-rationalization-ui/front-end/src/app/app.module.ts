import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { routes } from './app.routes';
import { AppRouteConfig } from './app.router.config';
import { Constants } from './models/constants.model';

// import { ModalModule } from 'angular2-modal';
// import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { FormsModule,FormControl, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { JsonpModule} from '@angular/http';
// import {  FileUploadModule } from 'ng2-file-upload';
import { LoadingModule , ANIMATION_TYPES } from 'ngx-loading';
// import {CKEditorModule} from 'ng2-ckeditor';
// import { ChartsModule } from 'ng2-charts/ng2-charts';
// import {ToastModule} from 'ng2-toastr/ng2-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AngularDraggableModule } from 'angular2-draggable';

import { AuthenticationService} from './services/security/authentication.service';
import { UserSvc} from './services/user/user.service';
import { ClientState} from './providers/clientstate.provider';
import { BaseHttpService} from './services/base-http.service';
import { DocumentSvc } from './services/document/document.service';
import { TemplateService } from './services/template/template.service';
import { ReportService } from './services/report/report.service';
import { UtilsService } from './services/utils.service';
import { LoaderService } from './services/loader/loader.service';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { TemplateListComponent } from './template-list/template-list.component';
import { ListComponent } from './list/list.component';
import { TemplateValidationComponent } from './template-validation/template-validation.component';
import { FileBrowserComponent } from './file-browser/file-browser.component';
import { TermsComponent } from './terms/terms.component';
import { ContextDistributionComponent } from './context-distribution/context-distribution.component';
import { SteppedProgressComponent } from './stepped-progress/stepped-progress.component';
import { OverviewComponent } from './overview/overview.component';
import { TemplateNameModalComponent } from './modal-views/template-name-modal/template-name-modal.component';
import { RejectNameModalComponent } from './modal-views/reject-name-modal/reject-name-modal.component';
import { TemplateDetailsComponent } from './template-details/template-details.component';
import { SettingsComponent } from './settings/settings.component';
import { DistributionLineComponent } from './distribution-line/distribution-line.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HomeComponent,
    TemplateListComponent,
    ListComponent,
    TemplateValidationComponent,
    FileBrowserComponent,
    TermsComponent,
    ContextDistributionComponent,
    SteppedProgressComponent,
    OverviewComponent,
    TemplateNameModalComponent,
    TemplateDetailsComponent,
    SettingsComponent,
    DistributionLineComponent,
    RejectNameModalComponent
  ],
  imports: [
    BrowserModule,
    routes,
    FormsModule,
    HttpModule,
    JsonpModule,
    AngularDraggableModule,
    // ModalModule.forRoot(),
    BootstrapModalModule,
    LoadingModule.forRoot({
        animationType : ANIMATION_TYPES.threeBounce,
        backdropBackgroundColour: 'rgba(0,0,0,0,1)',
        backdropBorderRadius: '4px',
        primaryColour : '#00fa01',
        secondaryColour : '#aeaea2',
        tertiaryColour: '#ffffff'
    })
  ],
  providers: [AppRouteConfig, Constants,ClientState, AuthenticationService, UserSvc,BaseHttpService,DocumentSvc,TemplateService, UtilsService,
    LoaderService,
    ReportService],
  bootstrap: [AppComponent],
  entryComponents: [ TemplateNameModalComponent, RejectNameModalComponent ]
})
export class AppModule { }

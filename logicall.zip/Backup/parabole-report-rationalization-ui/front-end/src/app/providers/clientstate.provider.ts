import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {UserVM} from "../models/user.model";


@Injectable()

export class ClientState{
  
    loggedUser : UserVM
    CURRENT_STATE:string;
}
import { Injectable , EventEmitter}     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {ContextVM} from "../models/context.model";
import {ContextWeightVM} from "../models/contextweight.model";
import * as _ from 'underscore';


import { ClientState } from '../providers/clientstate.provider';



@Injectable()
export class UtilsService {

    r_color=165;
    g_color=0;
    b_color=0;
    color:string;
    public modalChange: EventEmitter<any>;

    constructor(private clientState:ClientState){
        this.modalChange= new EventEmitter();
    }

    notifyTemplateNameModalData(data){
        this.modalChange.emit(data);
    }

    updateWeightAndColor(contextsList : any[]){
        this.r_color=165;
        this.g_color=0;
        this.b_color=0;

        // var context_len = 0;
        // contextsList.forEach(obj=>{
        //     context_len++;
        // })
                
        contextsList.forEach(obj=>{
            // obj.isSelected=false;
            obj.value=(obj.weight*100).toFixed(2)+"%";
            // var ctxObj = this.clientState.contextsColors[obj.contextURI];
            // if(ctxObj != undefined){
            //     obj.contextId = obj.id = ctxObj.id;
            //     obj.contextName = obj.name = ctxObj.name;
            //     var hashcodeval = this.hashfunction(obj.name);
            //     obj.color = this.colorGenerator(hashcodeval, context_len);
            // }
        })
        return contextsList;
    }

}

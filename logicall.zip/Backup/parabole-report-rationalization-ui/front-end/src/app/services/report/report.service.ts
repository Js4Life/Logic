import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {BaseHttpService} from "../../services/base-http.service";
import {HttpVerbs} from '../../models/constants.model'

import { ClientState} from '../../providers/clientstate.provider';

declare var stringformat : any;

@Injectable()
export class ReportService extends BaseHttpService {
    myURL : string = this.baseUrl;

    constructor( appState: ClientState, http: Http ){
        super(appState, http);
    }

    updateUserConfidence(reportId:string,userConfidenceMatch:any) :Promise<any>{
        // var remUrl = stringformat(URLs.GET_REPORT_BY_ID.url,this.filterIdString(reportId));
        var remUrl = 'reportRationalization/report/'+ this.filterIdString(reportId)+'/confidence';
        
        return this
                .invokeService(this.myURL+remUrl,userConfidenceMatch,HttpVerbs.PUT,' ')
                // .then(data => data.data);
                .then(data => data.data);
    }
    
}


var URLs = {
  GET_REPORT_BY_ID : {
      url : "reportRationalization/report/{0}/confidence",
      propname : "" 
  }             
}
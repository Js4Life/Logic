import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { HttpVerbs } from '../../models/constants.model'
import { BaseHttpService } from '../../services/base-http.service';
import { environment } from '../../../environments/environment';
import { ClientState } from '../../providers/clientstate.provider';



@Injectable()
export class DocumentSvc extends BaseHttpService {

  myURL: string = environment.BASE_URL;
  ReportId: any;

  constructor(appState: ClientState, http: Http) {
    super(appState, http);
  }

  uploadANewDocument(doc: FormData): Promise<any> {
    const remUrl = URLs.REPORT_ANALYSIS.url;
    return this
      .invokeService(this.myURL + remUrl, doc, HttpVerbs.POST, 'multipart/form-data')
      .then(data => data
      );
  }

  learning(): Promise<any> {
    const remUrl = URLs.LEARN.url;
    return this
      .invokeService(this.myURL + remUrl, ' ', HttpVerbs.GET, '')
      .then(data => data
      );
  }


  getTemplates(report: any): Promise<any> {
    var remUrl = 'reportRationalization/reportAnalysis/' + report + '/templates';
    return this
      .invokeService(this.myURL + remUrl, ' ', HttpVerbs.GET, '')
      .then(data => data);
  }

  getUnlinked() {
    var remUrl = 'reportRationalization/reportAnalysis/unlinked';
    return this
      .invokeService(this.myURL + remUrl, ' ', HttpVerbs.GET, '')
      .then(data => data);
  }
}


var URLs = {
  REPORT_ANALYSIS: {
    url: "reportRationalization/reportAnalysis",
    propname: "uploadReport"
  },
  LEARN: {
    url: "reportRationalization/learn",
    propname: "triggerLearning"
  },
  TEMPLATES_BY_LEARNINGID: {
    url: "reportRationalization/reportAnalysis/{0}/templates",
    propname: "templates"
  }
}

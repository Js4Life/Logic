import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {BaseHttpService} from "../../services/base-http.service";
import {HttpVerbs} from '../../models/constants.model'

import { ClientState} from '../../providers/clientstate.provider';

declare var stringformat : any;

@Injectable()
export class TemplateService extends BaseHttpService {
    myURL : string = this.baseUrl;

    constructor( appState: ClientState, http: Http ){
        super(appState, http);
    }

    getReportAnalysis(): Promise<any>{
      const remUrl = URLs.GET_REPORT_ANALYSIS.url;
      return this
              .invokeService(this.myURL + remUrl, "", HttpVerbs.GET, ' ')
              .then(data => data.data[URLs.GET_REPORT_ANALYSIS.propname]);
    }
    getTemplateById(templateId:string) :Promise<any>{
        // var remUrl = stringformat(URLs.GET_TEMPLATE_BY_ID.url,this.filterIdString(templateId));
        var remUrl = 'reportRationalization/template/'+ this.filterIdString(templateId);
        return this
                .invokeService(this.myURL+remUrl, "", HttpVerbs.GET, ' ')
                // .then(data => data.data);
                .then(data => data.data[URLs.GET_TEMPLATE_BY_ID.propname]);
    }
    acceptTemplateNameById(templateId:string,obj:any) : Promise<any>{
        var remUrl = 'reportRationalization/template/'+ this.filterIdString(templateId) + '/accept';
        return this
                .invokeService(this.myURL+remUrl, obj, HttpVerbs.PUT, ' ')
                .then(data => data.data[URLs.ACCEPT_TEMPLATE_BY_ID.propname]);
    }
    RejectTemplateById(templateId:string) : Promise<any>{
        var remUrl = 'reportRationalization/template/'+ this.filterIdString(templateId) + '/reject';
        return this
                .invokeService(this.myURL+remUrl, '{}', HttpVerbs.PUT, ' ')
                .then(data => data.data);
                // .then(data => data.data[URLs.GET_TEMPLATE_BY_ID.propname]);
    }

}


var URLs = {
  GET_REPORT_ANALYSIS : {
      url : "reportRationalization/reportAnalysis",
      propname : "reportAnalysis"
  },
  GET_TEMPLATE_BY_ID : {
      url : "reportRationalization/template/{0}",
      propname : "template"
  },
  ACCEPT_TEMPLATE_BY_ID : {
      url : "reportRationalization/template/{0}/accept",
      propname : "acceptTemplate"
  }
}

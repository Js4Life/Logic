import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SteppedProgressComponent } from './stepped-progress.component';

describe('SteppedProgressComponent', () => {
  let component: SteppedProgressComponent;
  let fixture: ComponentFixture<SteppedProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SteppedProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SteppedProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

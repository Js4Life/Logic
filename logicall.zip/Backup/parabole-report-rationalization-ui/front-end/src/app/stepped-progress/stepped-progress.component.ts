import { Component, OnInit, Input } from '@angular/core';
declare var $:any;

@Component({
  selector: 'stepped-progress',
  templateUrl: './stepped-progress.component.html',
  styleUrls: ['./stepped-progress.component.css']
})
export class SteppedProgressComponent implements OnInit {

  @Input() nodes:any;

  noOfNodes:number = 0;
  classname:string;

  constructor() { }

  createTemplateDef(){
    this.noOfNodes = this.nodes.length;
    this.classname = 'col-xs-'+(12/this.noOfNodes);
    // $(".bs-wizard-step").addClass(classname);
    this.nodes.forEach(obj => {
      
    });
  }

  ngOnInit() {
    this.createTemplateDef();
  }

}

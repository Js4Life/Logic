import { Component, OnInit, AfterViewInit, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import { Modal } from 'angular2-modal/plugins/bootstrap';

import { TemplateService } from '../services/template/template.service';
import { UtilsService } from '../services/utils.service';
import { AppRouteConfig } from '../app.router.config';
import { TemplateNameModalComponent } from '../modal-views/template-name-modal/template-name-modal.component';
import { RejectNameModalComponent } from '../modal-views/reject-name-modal/reject-name-modal.component';
import { DialogService } from "ng2-bootstrap-modal";


import * as _ from 'underscore';
declare var $:any;

@Component({
  selector: 'template-list',
  templateUrl: './template-list.component.html',
  styleUrls: ['./template-list.component.css']
})
export class TemplateListComponent implements OnInit, AfterViewInit {

  statusOptions:any = [
    {id:'NOTSTARTED',name:'Pending Validation'},
    {id:'INPROGRESS',name:'In Progress'},
    {id:'APPROVED',name:'Accepted'},
    {id:'REJECTED',name:'Rejected'}
  ]
  templateContOptions:any = [
    {id:'overview', name:'Overview'},
    {id:'constituentReports', name:'Constituent Reports'}
  ]
  selectedReport_template:any=null;
  isTemplateApproved:boolean = false;
  overviewEmittedId:string;
  modalEmittedData:any;

  templateList = null;
  tempListByStatus:any = {};
  selectedTemplateStatus:string;

  loading = false;

  constructor(private templateSvc : TemplateService, private utilSvc:UtilsService,vcRef: ViewContainerRef,
    public arc:AppRouteConfig, private dialogService:DialogService) {
    this.utilSvc.modalChange.subscribe(data=>{
      if(data){
        this.selectedReport_template.name = data.name;
        this.selectedReport_template.description = data.description;
        this.templateSvc.acceptTemplateNameById(this.selectedReport_template.id,this.selectedReport_template).then(data=>{
          if(data)
            this.arc.gotoPage('templateValidation/'+this.selectedReport_template.id);
        })
      }
    })
  }

  toggleAcceptanceStatus() {
    this.isTemplateApproved = !this.isTemplateApproved;
  }



  onClickTabs(optId){
    $("#"+optId).addClass('active').siblings().removeClass('active');
    this.changeTemplateList(optId);

  }

  cancelOverLay(){
    this.overviewEmittedId = null;
  }
  changeTemplateList(optId){
    this.selectedTemplateStatus = optId;
    switch(optId){
      case 'NOTSTARTED':
      this.selectedReport_template = null; // to disable template-details when clicked on other tabclick list
        break;
      case 'APPROVED':
        this.selectedReport_template = null;
        break;
      case 'REJECTED':
        this.selectedReport_template = null;
        break;
    }
  }

  templateChange(emittedData){
    console.log(emittedData);
    this.templateSvc.getTemplateById(emittedData.id).then(data=>{
      var data = data;
      data.contexts = this.utilSvc.updateWeightAndColor(data.contexts);
      this.selectedReport_template = data;
    })
  }

  getOverviewEmittedData(data){
    let optId=data.optId;
    this.overviewEmittedId = optId;
  }

  getTemplateList(){
    this.templateSvc.getReportAnalysis().then(data => {
      this.templateList = data[0].templates;
      this.tempListByStatus = _.groupBy(this.templateList, 'validationStatus');

      this.templateList.forEach((obj,index)=>{
        if(!obj.name)
          obj.name = 'Template '+parseInt(index+1);
        // obj.contexts = this.utilSvc.updateWeightAndColor(obj.contexts);
      })
      this.changeTemplateList(this.statusOptions[0].id);
    })
  }

  openModal(){
    let disposable = this.dialogService.addDialog(TemplateNameModalComponent, {}, { backdropColor: 'rgba(33, 41, 75, 0.58)' })
                .subscribe((isConfirmed)=>{
                    if (isConfirmed) {
                     // alert('accepted');
                    }
                    else {
                        // alert('declined');
                    }
                });
  }

  RejectModal() {
    let disposable = this.dialogService.addDialog(RejectNameModalComponent, {}, { backdropColor: 'rgba(33, 41, 75, 0.58)' })
    .subscribe((isConfirmed)=>{
        if (isConfirmed) {
          this.loading = true;
          this.templateSvc.RejectTemplateById(this.selectedReport_template.id).then(data=>{
            console.log(data);
            this.onInitialize();
            this.loading = false;
          });        }
        else {
              alert('declined');
        }
    });
}


  onContinueClick(){
    if (!this.selectedReport_template.name || this.selectedReport_template.name.trim()==''){
      this.openModal();
    } else {
      this.arc.gotoPage('templateValidation/' +this.selectedReport_template.id);
    }
  }
  onRejectClick() {
    if (!this.selectedReport_template.name || this.selectedReport_template.name.trim()!=''){
      this.RejectModal();
    }
  }

 onInitialize() {
  this.getTemplateList();

 }

  ngOnInit() {
    this.onInitialize();
  }

  ngAfterViewInit() {
    $("#"+this.statusOptions[0].id).addClass('active').siblings().removeClass('active');
  }

}

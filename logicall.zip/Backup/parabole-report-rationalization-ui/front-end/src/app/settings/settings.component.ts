import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  weights:any = [
    {name:"Terms", value:0.40, color:'#218e94'},
    {name:"Context Distribution", value:0.50, color:'#edc14a'},
    {name:"Related Terms", value:0.10, color:'#915996'},
  ]

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit,ElementRef, NgZone, ViewChild, ViewEncapsulation,Injectable} from '@angular/core';
import { Router} from '@angular/router';
import {Constants } from './models/constants.model';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class AppRouteConfig implements OnInit {

  constructor(public router : Router, private constants:Constants){

  }
  gotoLogin(){
    this.router.navigate(['./login']);
  }
  gotoPage(state){
    this.constants['PREVIOUS_STATE'] = this.constants['CURRENT_STATE'];
    this.constants['CURRENT_STATE'] = state;
    this.router.navigate(['./'+state]);
  }
  gotoDashboardChild(state){
    this.constants['PREVIOUS_STATE'] = this.constants['CURRENT_STATE'];
    // this.constants['CURRENT_STATE'] = this.router.url;
    this.constants['CURRENT_STATE'] = state;
    this.router.navigate(['./dashboard/'+state]);
  }
  goback(){
    this.constants['PREVIOUS_STATE'] = this.constants['CURRENT_STATE'];
    var prev = this.constants['PREVIOUS_STATE'];
    this.router.navigate(['./'+prev]);
  }

  ngOnInit() {
  }
}
import { Component, OnInit,Input, Output,EventEmitter  } from '@angular/core';

@Component({
  selector: 'overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {

  @Input() data:any;
  @Output() change: EventEmitter<any> = new EventEmitter<any>();

  terms:any=['Adverse', 'Debt', 'Amortization','Asset', 'Mortgage', 'Credit','Client','Borrower'];
  contexts:any=[
    {name:'Pricing', weight:18},
    {name:'Execution Frequency', weight:34},
    {name:'Time Value of Money', weight:65}
  ]

  constructor() { }

  onShowClick(optId){
    this.change.emit({optId:optId});
  }

  ngOnInit() {
  }

}

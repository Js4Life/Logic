import { Component, OnInit, Input, Output } from '@angular/core';
import {Constants } from '../models/constants.model';

import * as $ from 'jquery';
import * as _ from 'underscore';

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {

  @Input() reportTerms:any;
  @Input() templateTerms:any;
  @Input() showAllTerms:boolean;

  mixedTerms:any;
  showTermsPackets:boolean = false;

  objectKeys = Object.keys;

  relatedOrAllTerms:string;
  topRelatedOrTopTerms:string;
  dictTerms:any={};
  tempDictTerms:any={};
  
  alphabets:any=[
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
  ];

  distributionOptions:any = [
    {id:'report', name:'Report', count:0, color:'#e3eefa', isSelected:false},
    {id:'template', name:'Template', count:0, color:'#f5e1ff', isSelected:false},
    {id:'both', name:'Common to both', count:0, color:'#b5ffc1', isSelected:true},
  ]
  constructor(private constants:Constants) { }

  filterByAlphabet(alp,e){
    $(e.currentTarget).siblings().removeClass('activeAlpha');
    if(_.size(this.dictTerms)>1){
      this.tempDictTerms = this.dictTerms;
    }
    if(this.tempDictTerms)
      this.dictTerms = this.tempDictTerms;
    
    if(!e.currentTarget.className.includes('activeAlpha')){
      $(e.currentTarget).addClass('activeAlpha');
      let reqObj = {};
      reqObj[alp] = this.dictTerms[alp];
      this.dictTerms = reqObj;
    }
    else{
      $(e.currentTarget).removeClass('activeAlpha');
    }
  }

  changeOption(option){
    $('.alphabetList').children().removeClass('activeAlpha');
    if(option)
      option.isSelected = !option.isSelected;
    let arr=[];
    this.distributionOptions.forEach(obj=>{
      if(obj.isSelected)
        arr.push(obj.id);
    })
    if(arr.length>0)
      this.showTermsByOptions(arr);
  }

  showTermsByOptions(optIdArr){
    let tempTerms = [];
    optIdArr.forEach(optId=>{
      let tt = _.filter(this.mixedTerms, function(obj){ 
        if(obj.type==optId)
          return obj;
      })
      tempTerms = _.union(tempTerms,tt);
    })
    this.createDictionaryView(tempTerms);
  }

  createDictionaryView(tempTerms){
    this.alphabets.forEach(alp=>{
      this.dictTerms[alp] = [];
      this.dictTerms[alp] = _.filter(tempTerms, function(obj){ 
        if(obj.termValue.charAt(0).toLowerCase() == alp.toLowerCase())
          return {id:obj.termValue, name:obj.termValue};
      });
    })
  }

  ngOnInit() {
    if(!this.constants['CURRENT_STATE'] || this.constants['CURRENT_STATE'].includes('templateValidation')){
      this.showTermsPackets = true;
      this.mixedTerms = _.union(this.reportTerms, this.templateTerms);
      this.mixedTerms.forEach(obj=>{
        let tt = _.findWhere(this.templateTerms, {termValue:obj.termValue});
        let rt = _.findWhere(this.reportTerms, {termValue:obj.termValue});
        if(tt && rt){
          obj.type = 'both';
        }
        if(tt && !rt){
          obj.type = 'template';
        }
        if(!tt && rt){
          obj.type = 'report';
        }
      })
      this.changeOption(null);
    }
    else if(this.constants['CURRENT_STATE'] && this.constants['CURRENT_STATE'].includes('templateList')){
      this.createDictionaryView(this.templateTerms);
      this.showTermsPackets = false;
    }
  }

}

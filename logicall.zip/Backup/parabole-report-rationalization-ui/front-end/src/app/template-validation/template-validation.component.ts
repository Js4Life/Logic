import { Component, OnInit, } from '@angular/core';
import * as _ from 'underscore';
import { Observable }        from 'rxjs/Observable';
import { Subject }           from 'rxjs/Subject';
import { AppRouteConfig} from '../app.router.config';
import { Router , ActivatedRoute } from '@angular/router';


import * as $ from 'jquery';
// Observable class extensions
import 'rxjs/add/observable/of';

// Observable operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { TemplateService } from '../services/template/template.service';
import { ReportService } from '../services/report/report.service';
import { ReportTemplateVM } from '../models/reportTemplate.model';

@Component({
  selector: 'template-validation',
  templateUrl: './template-validation.component.html',
  styleUrls: ['./template-validation.component.css']
})
export class TemplateValidationComponent implements OnInit {

  reportTemplate: ReportTemplateVM = new ReportTemplateVM();
  sub:any;
  templateId:string='9:980';
  selectedReport:any=[];
  template:any;
  activeProgressTab:string='';
  relatedOrAllTerms:string;
  topRelatedOrTopTerms:string;
  showAllTerms:boolean;
  reports:any=[]

  allTermsArray:any=[];

  progressNodes:any = [
    {id:'terms',name:'Terms', status:'active'},
    {id:'contextDistribution',name:'Context Distribution', status:'pending'},
    {id:'relatedTerms',name:'Related Terms', status:'pending'}
    // {id:'completedstep',name:'completed Step', status:'complete'},
  ]
  percentageDist:any = [
    {id:0, index:0, range:'0-20', value:20},
    {id:0, index:1, range:'21-40', value:40},
    {id:0, index:2, range:'41-60', value:60},
    {id:0, index:3, range:'61-80', value:80},
    {id:0, index:4, range:'81-100', value:100}
  ]

  allRelatedTermsArray:any=[];
  topTermsArray:any=[];
  relatedTopTermsArray:any=[];
  termsArray:any=[];

  contextArray:any=[];

  constructor(private templateSvc : TemplateService, private reportService : ReportService, private route:ActivatedRoute) { }

  
  onReportTabClick(rep,idx){
    this.progressNodes = [];
    console.log(rep);
    $("#"+idx+'report').addClass('ActiveReportDiv').removeClass('inActiveReportDiv').siblings().removeClass('ActiveReportDiv').addClass('inActiveReportDiv');

    this.selectedReport=rep;  
    this.activeProgressTab='terms';
    this.relatedOrAllTerms='all';
    this.topRelatedOrTopTerms='top';
    this.showAllTerms=false;
    this.termsArray=rep.terms;
    this.progressNodes = [
      {id:'terms',name:'Terms', status:'active'},
      {id:'contextDistribution',name:'Context Distribution', status:'pending'},
      {id:'relatedTerms',name:'Related Terms', status:'pending'}
    ]
  }

  percentageTabClick(opt,e){
      if(this.activeProgressTab=='terms'){
        var confidenceMatch={key : 'userTermConfidenceLevel' , value : opt.value};
      }
      else if(this.activeProgressTab=='contextDistribution'){
        var confidenceMatch={key : 'userContextConfidenceLevel' , value : opt.value};
      }
      else if(this.activeProgressTab=='relatedTerms'){
        var confidenceMatch={key : 'userTermDistributionConfidenceLevel' , value : opt.value};
      }
      this.reportService.updateUserConfidence(this.selectedReport.id,confidenceMatch).then(data=>{
        console.log(data);
        var key = _.findIndex(this.progressNodes, function(obj){
          return obj.status=='active';
        })
        this.progressNodes[key].status = 'complete';
        if(this.progressNodes[key+1]){
          this.progressNodes[key+1].status = 'active';
          this.activeProgressTab = this.progressNodes[key+1].id;
        }
        else{
          //percent allocation for all progress tabs complete, so update status and goto next report
          let repId = this.selectedReport.id;
          var key = _.findIndex(this.reportTemplate.linkedReports, function(obj){
            return obj.id==repId;
          })
          if(this.reportTemplate.linkedReports[key+1])
            this.onReportTabClick(this.reportTemplate.linkedReports[key+1],key+1);
        }
      })
  }
  
  // PercentageTabClick(opt,e){
  //   if(opt!='next'){
  //     this.selectedPercentageMatch=opt;
  //     $(e.currentTarget).addClass('percenTabActive').siblings().removeClass('percenTabActive');
  //     this.selectedPercentageTab=e;
  //   }
  //   else if(opt=='next'){
  //     if(this.selectedPercentageMatch){
  //     $(this.selectedPercentageTab.currentTarget).removeClass('percenTabActive');
  //       if(this.activeProgressTab=='terms'){
  //       this.progressNodes = [
  //         {id:'terms',name:'Terms', status:'complete'},
  //         {id:'contextDistribution',name:'Context Distribution', status:'active'},
  //         {id:'relatedTerms',name:'Related Terms', status:'pending'}
  //       ]
  //       this.activeProgressTab='context';
  //       }
  //       else if(this.activeProgressTab=='context'){
  //         this.progressNodes = [
  //           {id:'terms',name:'Terms', status:'complete'},
  //           {id:'contextDistribution',name:'Context Distribution', status:'complete'},
  //           {id:'relatedTerms',name:'Related Terms', status:'active'}
  //         ]
  //         this.activeProgressTab='related terms';
  //       }
  //       else if(this.activeProgressTab=='related terms'){
  //         this.progressNodes = [
  //           {id:'terms',name:'Terms', status:'complete'},
  //           {id:'contextDistribution',name:'Context Distribution', status:'complete'},
  //           {id:'relatedTerms',name:'Related Terms', status:'complete'}
  //         ]
  //         this.activeProgressTab='related terms';
  //       }
        
  //     }
  //     else
  //       window.alert('Select a percentage match');
  //       this.selectedPercentageMatch='';
  //       $('#percentageContainerDiv').children().removeClass('percenTabActive');
  //     }
  // }

  allOrTopTerms(){
    this.showAllTerms=!this.showAllTerms;
  }

  getTemplateById(id){
    this.templateSvc.getTemplateById(id).then(data=>{
      console.log(data);
      this.reportTemplate=data;
      console.log('report Template');
      console.log(this.reportTemplate);
      this.onReportTabClick(this.reportTemplate.linkedReports[0],0);
      // this.termsArray=this.reportTemplate.terms;
    })
  }

  onInitialize(){
    this.sub = this.route.params.subscribe(params => {
      if(params['templateId'])
          this.templateId = params['templateId'];
      this.getTemplateById(this.templateId);
    });
  }

  ngOnInit(){
    this.onInitialize();
  }

}
import { Component, OnInit } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { UtilsService } from '../../services/utils.service';

@Component({
  selector: 'template-name-modal',
  templateUrl: './template-name-modal.component.html',
  styleUrls: ['./template-name-modal.component.css']
})
export class TemplateNameModalComponent extends DialogComponent<any, any> {

  template:any={name:null, description:null};

  constructor(public dialogService: DialogService, private utilSvc:UtilsService) { 
    super(dialogService);
  }

  onClick(opt){
    switch(opt){
      case 'continue':
        this.result = true;
        this.validate();
        break;
      case 'cancel':
        this.close();
        break;
    }
  }

  validate(){
    if(this.template.name && this.template.name.trim()!=''){
      this.utilSvc.notifyTemplateNameModalData(this.template);
      this.close();
    }
  }

  ngOnInit() {
  }

}

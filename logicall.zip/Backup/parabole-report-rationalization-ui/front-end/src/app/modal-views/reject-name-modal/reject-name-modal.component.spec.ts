import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectNameModalComponent } from './reject-name-modal.component';

describe('RejectNameModalComponent', () => {
  let component: RejectNameModalComponent;
  let fixture: ComponentFixture<RejectNameModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RejectNameModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectNameModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

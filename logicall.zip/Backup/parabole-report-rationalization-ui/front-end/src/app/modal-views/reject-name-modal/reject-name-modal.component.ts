import { Component, OnInit} from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";


@Component({
  selector: 'reject-name-modal',
  templateUrl: './reject-name-modal.component.html',
  styleUrls: ['./reject-name-modal.component.css']
})
export class RejectNameModalComponent extends DialogComponent<any, any> {

  constructor(public dialogService: DialogService) {
    super(dialogService);

  }

  onClick(opt){
    switch(opt){
      case 'continue':
        this.result = true;
        this.reject();
        break;
      case 'cancel':
        this.close();
        break;
    }
  }

  reject() {
   this.close();

  }

  ngOnInit() {
  }

}

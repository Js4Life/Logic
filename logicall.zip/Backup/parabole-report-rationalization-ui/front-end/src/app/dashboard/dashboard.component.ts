import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {Observable} from 'rxjs/Rx';
import { AppRouteConfig } from '../app.router.config';


declare var $:any;
@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public showStyle: boolean = false;

  sub:any;
  user:any;


  navOptions:any=[
    // {id:'fileBrowser', name:'File Browser',children:[]},
    {id:'learning', name:'Learning',icon:'learning-light',children:[
      {id:'learninglibrary', name:'Learning Library',icon:'report-library-selected'},
      {id:'templates', name:'Templates',icon:'templates-selected'},
      {id:'settings', name:'Settings',icon:'settings-not-selected'}
    ]}
  ]
  constructor(private route: ActivatedRoute,public router : Router, public arc:AppRouteConfig) { }

  onNavClick(opt,e){
    if(opt.children && opt.children.length>0){
      $('#'+opt.id+'children').collapse('toggle');
    }
    if(opt.children && opt.children.length==0){
      $('#'+opt.id).addClass('active').siblings().removeClass('active');
      $('#'+opt.id).parent().siblings().children().removeClass('active');
    }
    if(!opt.children){
      $('#'+opt.id).addClass('active').siblings().removeClass('active');
      $('#'+opt.id).parent().siblings().children().removeClass('active');
    }
    switch(opt.id){
      case 'learninglibrary':
          this.arc.gotoDashboardChild('learninglibrary');
          break;
      case 'templates':
          this.arc.gotoDashboardChild('templateList');
          break;
      case 'settings':
          this.arc.gotoDashboardChild('settings');
          break;
    }
  }


  onIntialise(){
  }

  ngOnInit() {
    // this.sub = this.route.params.subscribe(params => {
    //    var role = params['role'];
    //    this.user = JSON.parse(localStorage.getItem(Constants.LOGGED_USER));
    // });
    this.onIntialise();
  }
  ngAfterViewInit() {
      this.onNavClick(this.navOptions[0].children[0],null);
  }

  signOut(){
    // localStorage.clear();
    this.arc.gotoLogin();
  }

}

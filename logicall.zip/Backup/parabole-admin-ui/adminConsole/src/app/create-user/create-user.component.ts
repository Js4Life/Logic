import { Component, OnInit } from '@angular/core';
import { CreateSvc } from '../services/createUser.service';
import { RoleSvc } from '../services/role.service';
import { HttpService } from '../services/http.service';
import { CreateUser } from '../models/createUser.model';
import { NotificationsService } from 'angular2-notifications';
import {APIList} from '../../environments/api';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  userInput: CreateUser = new CreateUser();
  roleArr: any = [];
  options = {
    position: ['top', 'right'],
    timeOut: 5000,
    lastOnBottom: true
};

  constructor(private createSvc: CreateSvc, private http: HttpService, private roles: RoleSvc , private _service: NotificationsService ) { }

  createUser() {
    console.log(this.userInput);
    this.createSvc.createUsers(this.userInput).then(data => {
      console.log(data);
      this._service.success('Success', 'User created Sucessfully' );
      this.userInput.name = null;
      this.userInput.userId =null;
      this.userInput.password = null;
    });
   // this.userInput = null;
  }

  getAllRoles() {
    this.roles.getRoles().then(data => {
      console.log(data['data'].roles); // to check
      this.roleArr = data['data'].roles;
    });
  }

  onOptionsSelected(role) {
    this.userInput.role.roleId = role.roleId;
    this.userInput.role.id = role.id;
  }

  ngOnInit() {
    this.getAllRoles();
  }

}


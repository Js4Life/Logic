import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-golden',
  templateUrl: './golden.component.html',
  styleUrls: ['./golden.component.css']
})
export class GoldenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

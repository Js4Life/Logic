import {ModuleWithProviders} from '@angular/core';
import {Routes , RouterModule} from '@angular/router';
import {LoginComponent} from './login/login.component';
import { OperationComponent } from './operation/operation.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import {ContextComponent} from './context/context.component'
import { FolderComponent } from './folder/folder.component';
import { RolesComponent } from './roles/roles.component';
import { GetuserComponent } from './getuser/getuser.component';
import { GoldenComponent } from './golden/golden.component';
import { ExportComponent } from './export/export.component';
import {UserManualComponent} from './user-manual/user-manual.component';
import {VocabsComponent} from './vocabs/vocabs.component';
import { CreateUserComponent } from './create-user/create-user.component';

export const router: Routes = [
    {path: '', component: LoginComponent},
    {
        path: 'operation', component : OperationComponent,
        children: [
                    {path: 'dboperations' , component : ContextComponent, pathMatch: 'full'},
                    {path: 'preparefolder' , component : FolderComponent, pathMatch: 'full'},
                    {path: 'createrole' , component : RolesComponent, pathMatch: 'full'},
                    {path: 'getusers' , component : GetuserComponent, pathMatch: 'full'},
                    {path: 'export' , component : ExportComponent, pathMatch: 'full'},
                    {path: 'goldenset' , component : GoldenComponent, pathMatch: 'full'},
                    {path: 'guide' , component : UserManualComponent, pathMatch: 'full'},
                    {path: 'getVocabs' , component : VocabsComponent, pathMatch: 'full'},
                    {path: 'createUser' , component : CreateUserComponent, pathMatch: 'full'},
                   ]
    }
    ,
    {
        path: '', redirectTo: '/operation', pathMatch: 'full'
    },{
        path: '**', component: PageNotFoundComponent
    }
    // wildcard route
];

export const routes: ModuleWithProviders = RouterModule.forRoot(router);

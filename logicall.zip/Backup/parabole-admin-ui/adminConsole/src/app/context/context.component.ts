import { Component, OnInit } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpService } from '../services/http.service';
import { NotificationsService } from 'angular2-notifications';
declare var $: any;
import { APIList } from '../../environments/api';

@Component({
  selector: 'app-context',
  templateUrl: './context.component.html',
  styleUrls: ['./context.component.css']
})
export class ContextComponent {
  //  URLs
  // private _url1: string = environment.BASE_URL + '/api/v1/admin/cleanDB';
  // private _url2: string = environment.BASE_URL + '/api/v1/jenatdb/saveContextToDB';
  // private _url3: string = environment.BASE_URL + '/api/v1/jenatdb/saveAllComponentToDB';
  // private _url4: string = environment.BASE_URL + '/api/v1/jenatdb/saveAllBusinessSegmentToDB';
  // private _url5: string = environment.BASE_URL + '/api/v1/jenatdb/saveAllProductToDB';
  // private _url6: string = environment.BASE_URL + '/api/v1/masterdata/wordDictionary';




  statusCheck: Boolean;
  loading: boolean = false;
  arrayData: any;
  bodyData: any;
  options = {
    position: ["bottom", "right"],
    lastOnBottom: true,
    animate: 'fromRight',
    timeOut: 20000,
    showProgressBar: false,
    pauseOnHover: true,
    clickToClose: false
  };
  AdminURLs = {
    CLEAN_DB: {
      url: "/api/v1/admin/cleanDB",
      propname: "clean DB"
    },
    SAVE_CONTEXT: {
      url: "/api/v1/jenatdb/saveContextToDB",
      propname: "Save Context"
    },
    SAVE_ALL_COMPONENTS: {
      url: "/api/v1/jenatdb/saveAllComponentToDB",
      propname: "Save All Components"
    },
    SAVE_ALL_BUSSINESS_SEGMENTS: {
      url: "/api/v1/jenatdb/saveAllBusinessSegmentToDB",
      propname: "Save All Bussiness Segments"
    },
    SAVE_PRODUCTS: {
      url: "/api/v1/jenatdb/saveAllProductToDB",
      propname: "Save all products"
    },
    WORD_DICTIONARY: {
      url: "/api/v1/masterdata/wordDictionary",
      propname: "get Word Dictionary"
    },
    KNOWLEDGE_TO_DB: {
      url: "/api/v1/jenatdb/saveKnowledgeToDB",
      propname: "Knowledge to DB"
    }
  };

  private _url1: string = environment.BASE_URL + APIList.AdminURLs.CLEAN_DB.url;
  private _url2: string = environment.BASE_URL + APIList.AdminURLs.SAVE_CONTEXT.url;
  private _url6: string = environment.BASE_URL + APIList.AdminURLs.WORD_DICTIONARY.url;
  private _url7: string = environment.BASE_URL + APIList.AdminURLs.KNOWLEDGE_TO_DB.url;

  // removed
  private _url3: string = environment.BASE_URL + this.AdminURLs.SAVE_ALL_COMPONENTS.url;
  private _url4: string = environment.BASE_URL + this.AdminURLs.SAVE_ALL_BUSSINESS_SEGMENTS.url;
  private _url5: string = environment.BASE_URL + this.AdminURLs.SAVE_PRODUCTS.url;



  // clean DB

  delete() {
    return this.httpService.invokeService(this._url1, '', 3);
  }

  cleanDb() {
    // this.loading = true;
    this.delete().then(data => {
      console.log(data);
      this.statusCheck = data['status'];
      if (this.statusCheck) {
        // $('#cleanDb').modal('show');
        this._service.success('Success', 'Clean DB');
      } else {
        this._service.error('Error', 'Cleaning DB');
      }
    });
  }


  // Load Context

  context() {
    this.loading = true;
    return this.httpService.invokeService(this._url2, '', 2);
  }

  loadContext() {
    this.context().then(data => {
      this.arrayData = data['status'];
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Contexts Loaded');
      } else {
        this._service.error('Error', 'Contexts Loaded')
      }
    });
  }

  // Load Components and its type

  component() {
    this.loading = true;
    return this.httpService.invokeService(this._url3, ' ', 2);
  }

  loadComponent() {
    this.component().then(data => {
      this.arrayData = data['status'];
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Components Loaded');
      }
    });
  }

  // load Bussiness segments

  segments() {
    this.loading = true;
    return this.httpService.invokeService(this._url4, '', 2);
  }

  loadSegments() {
    this.segments().then(data => {
      console.log(data);
      this.arrayData = data['status'];
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Segments Loaded');
      }
    });
  }

  // load Products

  product() {
    this.loading = true;
    return this.httpService.invokeService(this._url5, '', 2);
  }

  loadProduct() {
    this.product().then(data => {
      this.arrayData = data['status'];
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Products Loaded');
      }
    });
  }

  // word Dictionary

  dictionary() {
    this.loading = true;
    const body = { 'body': this.bodyData };
    return this.httpService.invokeService(this._url6, body, 1);
  }

  loadDictionary() {
    this.dictionary().then(data => {
      console.log(data['data'].dumpWordDictionary);
      this.arrayData = data['data'].dumpWordDictionary;
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Dictionary Loaded');
      } else {
        this._service.error('Error', 'Creating Word Dictionary');
      }
    });
  }

  // knowledgeToDB

  knowledge() {
    this.loading = true;
    return this.httpService.invokeService(this._url7, '', 2);
  }

  knowledgeToDB() {
    this.knowledge().then(data => {
      this.arrayData = data['status'];
      this.loading = false;
      if (this.arrayData) {
        this._service.success('Success', 'Knowledge to DB');
      } else {
        this._service.error('Error', 'Knowledge Saving to DB');
      }
    });
  }

  constructor(private httpService: HttpService, private _service: NotificationsService) {

  }
  ngOnInit() {

  }

}

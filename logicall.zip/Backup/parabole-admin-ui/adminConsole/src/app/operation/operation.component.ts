import { Component, OnInit } from '@angular/core';
import {AppRouteConfig} from '../app.router-config';
import {ActivatedRoute} from '@angular/router';
import * as $ from 'jquery';
@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.css']
})
export class OperationComponent implements OnInit {
  cleandb: Boolean = false;
  context: Boolean = false;
  heading: Boolean = false;
  ev: Boolean;

  loadDB(e) {
   $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/dboperations');
  }

  prepareFolder(e) {
    $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/preparefolder');
    this.heading = false;
  }
  createRoles(e) {
    $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/createrole');
    this.heading = false;
  }
  userManual(e) {
    $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/guide');
    this.heading = false;
  }

  getVocab(e) {
    $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/getVocabs');
    this.heading = false;
  }

  createUsers(e) {
    $(e.currentTarget).addClass('selectClass').siblings().removeClass('selectClass');
    this.goto.goToLogin('/operation/createUser');
    this.heading = false;
  }


  constructor(public goto: AppRouteConfig , public route: ActivatedRoute) {
      this.route.url.subscribe(params => {
       //  console.log(params[0]);
      });
   }

  ngOnInit() {
  }

}


// dbclean(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');

//  this.goto.goToLogin('/operation/cleandb');
//  this.heading = false;
// }

// loadcontext(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/loadcontext');
//   this.heading = false;
// }

// loadComponent(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/operation');
//   this.heading = false;
// }

// loadSegments(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/loadSegments');
//   this.heading = false;
// }

// loadProduct(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/loadProduct');
//   this.heading = false;
// }




// loadDictonay(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/dictionary');
//   this.heading = false;
// }
// getUser(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/getusers');
//   this.heading = false;
// }

// importDb(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/import');
//   this.heading = false;
// }

// exportDb(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/export');
//   this.heading = false;
// }

// goldenSet(e) {
//   $(e.currentTarget).addClass('active').parent().siblings().children().removeClass('active');
//   this.goto.goToLogin('/operation/goldenset');
//   this.heading = false;
// }


import { Component, OnInit } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpService} from '../services/http.service';
import {RoleVM} from '../models/role.model';
import {RoleSvc} from '../services/role.service';
import { NotificationsService } from 'angular2-notifications';
import {APIList} from '../../environments/api';



@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  roleArray: any;
  private _url: string = environment.BASE_URL + APIList.AdminURLs.CREATE_ROLE.url;
  roleData: any = {};
  passData: any;
  loading: boolean = false;
  arrayData: any;
  options = {
    position: ['top', 'right'],
    timeOut: 5000,
    lastOnBottom: true
};


getRoles() {
  this.loading = false;
    return this.http.invokeService(this._url, '', 2);
}

createRole() {
    this.passData = { name: this.roleData.name , roleId: this.roleData.roleId};
    console.log(this.roleData);
    this.Role.createRole(this.passData).then(data => {
    console.log(data);
    this.arrayData = data['status'];
    this.loading = false;
    this.getList();
    this._service.success('Success', `${this.roleData.name} Role created`);
    });

}

constructor(private Role: RoleSvc, private http: HttpService,
   private _service: NotificationsService ) {

}

onInitiate() {
  this.getRoles().then( data => {
    console.log(data['data'].roles);
    this.roleArray = data['data'].roles;
    this.loading = false;
    // if (this.roleArray == undefined) {
    //   this._service.error('Error','Getting role List');
    // }
       });
}

getList() {
  this.onInitiate();
}

ngOnInit() {
    this.getList();
 }

}




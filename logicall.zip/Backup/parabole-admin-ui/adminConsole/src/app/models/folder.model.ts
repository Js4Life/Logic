export class FolderModel {
  parentFolderName: string;
  parentFolderId: string;
  children: Array<any>;
  documentList: Array<any>;
}

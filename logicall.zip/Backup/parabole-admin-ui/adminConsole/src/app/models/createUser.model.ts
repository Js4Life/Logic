import { RoleVM } from '../models/role.model';

export class CreateUser {
  role: RoleVM = new RoleVM();
  userId: string;
  password: string;
  name: string;
}

export class Constants{
  static LOGIN_RESPONSE : string = "loginResponse";
  static CURRENT_STATE : string = "currentState";
}

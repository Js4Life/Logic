export class RoleVM {
    name: string;
    roleId: Number;
     id ?: string;

}

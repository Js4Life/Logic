import { Component, OnInit } from '@angular/core';
import {environment} from '../../environments/environment';
// import {HttpService} from '../services/http.service';
import {FolderModel} from '../models/folder.model';
import {FolderSvc} from '../services/folder.service';
import { NotificationsService } from 'angular2-notifications';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.css']
})
export class FolderComponent  {
  formdata: any = {};
  isCopied1:boolean = false;
  results: any;
  loading: boolean = false;
  options = {
    position: ['top', 'right'],
    timeOut: 5000,
    lastOnBottom: true
};


createAFolder() {
   this.loading = true;
  this.formdata = { name: this.formdata.folderName, parentFolderId: this.formdata.parentId ,
    parentFolderName:'', children:[], documentList:[]};
  this.FoldSvc.createAFolder(this.formdata).then(data => {
  this.formdata.id = data['id'].slice(1);
  this.loading = false;
  var Createdfolder = data['name']
  this._service.success('Success', `${Createdfolder} Folder Created`);
  });
}
constructor(private FoldSvc: FolderSvc,private _service:NotificationsService) {}




  ngOnInit() {

  }

}

import {Injectable, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Injectable()
export class AppRouteConfig implements OnInit {
    constructor(public router: Router) { }

 goToLogin(state) {
    this.router.navigate(['./' + state]);
 }

   ngOnInit() {}
}

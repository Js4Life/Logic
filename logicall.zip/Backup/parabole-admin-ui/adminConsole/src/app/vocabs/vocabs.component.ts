import { Component, OnInit } from '@angular/core';
import {HttpService} from '../services/http.service';
import {environment} from '../../environments/environment';
import { NotificationsService } from 'angular2-notifications';
import {APIList} from '../../environments/api';

@Component({
  selector: 'app-vocabs',
  templateUrl: './vocabs.component.html',
  styleUrls: ['./vocabs.component.css']
})
export class VocabsComponent {

  private _url: string = environment.BASE_URL + '/api/v1/admin/triggerIndexBuilderForDB';
  userArray: any;
  loading:boolean = false;
  arrayData;
  options = {
    position: ["bottom", "right"],
    lastOnBottom: true,
    animate: 'fromRight',
    timeOut: 20000,
    showProgressBar: false,
    pauseOnHover: true,
    clickToClose: false
  };
  btn: string = APIList.AdminURLs.BUTTON_NAME.name;

  getVocabs() {
    this.loading = true;
    return this.httpService.invokeService(this._url, '', 2);
   }

   trigger() {
     this.getVocabs().then( data => {
       console.log(data['status']);
       this.arrayData = data['status'];
       this.loading = false;
       if (this.arrayData) {
           this._service.success('Success', 'Initiate DB');    }
       if (this.arrayData == false) {
        this._service.error('Fail', 'Initiate DB');
       }
     });
    }
    constructor(private httpService: HttpService, private _service: NotificationsService) {

    }

   ngOnInit() { }
  }
  //   this.getList().then( data => {
  //   this.userArray = data['data'].users;
  //   this.loading = false;
  //        });
  //  }


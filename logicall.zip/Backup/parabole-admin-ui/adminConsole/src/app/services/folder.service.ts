import {Injectable} from '@angular/core';
import {HttpService} from './http.service';
import { environment } from '../../environments/environment';
import {FolderModel} from '../models/folder.model';
import {APIList} from '../../environments/api';

@Injectable()
export class FolderSvc extends HttpService {

  private _url: string = environment.BASE_URL + APIList.AdminURLs.CREATE_FOLDER.url;

createAFolder(folder: FolderModel): Promise<FolderModel>{
    return this
            .invokeService(this._url, folder, 1)
            .then( data => data.data['folder']);
}


}

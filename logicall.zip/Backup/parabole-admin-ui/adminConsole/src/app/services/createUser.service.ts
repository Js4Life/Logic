import { Injectable } from '@angular/core';
import { CreateUser } from '../models/createUser.model';
import { HttpService } from './http.service';
import { environment } from '../../environments/environment';
import {APIList} from '../../environments/api';

@Injectable()
export class CreateSvc extends HttpService {
  myURL: string = environment.BASE_URL + APIList.AdminURLs.CREATE_USER.url;

  createUsers(createUserData: CreateUser) {
    return this.invokeService(this.myURL, createUserData, 1).then(data => data.data);
  }

}


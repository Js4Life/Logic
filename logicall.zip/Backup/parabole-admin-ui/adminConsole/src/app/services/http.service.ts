import { Injectable, Output,EventEmitter } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable} from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';
import { Jsonp} from '@angular/http';
import { ResponseModel} from '../models/response.model';

import { environment } from '../../environments/environment';
import { Constants} from '../models/constants.model';


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export  class HttpService {

    protected baseUrl:string =  environment.BASE_URL;

    constructor(private http: Http) {
    }

    invokeService(url,data,methodType) : Promise<ResponseModel> {

        var resObservable : Observable<ResponseModel>;
        var httpResponseErr : ResponseModel ;

        switch( methodType ){
            case 1:
            resObservable = this.postData(url,data);
            break;
            case 2:
            resObservable = this.getData(url);
            break;
            case 3:
            resObservable = this.deleteData(url);
            break;
            case 4:
            resObservable = this.putData(url,data);
            break;
        }

        return resObservable
            .map(data => data)
            .toPromise()
            .then(data => {
                return data;
            })
            .catch((error: any) => {
                httpResponseErr = new ResponseModel();
                httpResponseErr.status = false;
                httpResponseErr.statusCode = error.status;

                return httpResponseErr;
            });

    }


    postData(url, obj): Observable<ResponseModel> {
        return this.http.post(url, obj, { headers: this.tokenAuthorizer() })
            .map(data => data.json())
            .catch((error: any) => Observable.throw(error || 'Server error'));
    }

    getData(url): Observable<ResponseModel> {
        return this.http.get(url, { headers: this.tokenAuthorizer() })
            .map(data => data.json())
            .catch((error: any) => Observable.throw(error || 'Server error'));
    }

    putData(url, obj): Observable<ResponseModel> {
        return this.http.put(url, obj, { headers: this.tokenAuthorizer() })
            .map(data => data.json())
            .catch((error: any) => Observable.throw(error || 'Server error'));

    }

    deleteData(url): Observable<ResponseModel> {
        return this.http.delete(url, { headers: this.tokenAuthorizer() })
            .map(data => data.json())
            .catch((error: any) => Observable.throw(error || 'Server error'));
    }

    tokenAuthorizer(){
         let headers = new Headers({'Content-Type': 'application/json'});

         var currUser = localStorage.getItem(Constants.LOGIN_RESPONSE);
         if(!currUser || currUser == "undefined"){
            localStorage.clear();
            headers.append('Authorization' , "Bearer " +  '');
            return headers;
         }
         else{
            var token = JSON.parse(currUser).token;
            headers.append('Authorization' , "Bearer " +  token);
            return headers;
         }

    }


}

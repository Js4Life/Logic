import {Injectable} from '@angular/core';
import {HttpService} from './http.service';
import { environment } from '../../environments/environment';
import {RoleVM} from '../models/role.model';
import {APIList} from '../../environments/api'

@Injectable()
export class RoleSvc extends HttpService {


  private _url: string = environment.BASE_URL + APIList.AdminURLs.CREATE_ROLE.url;

  createRole(role: RoleVM): Promise<RoleVM> {
      return this
              .invokeService(this._url, role, 1)
              .then( data => data.data['roles']);
  }

  getRoles(){
      return this.invokeService(this._url, '', 2);
  }

}

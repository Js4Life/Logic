import { Component, OnInit } from '@angular/core';
import {HttpService} from '../services/http.service';
import {environment} from '../../environments/environment';

@Component({
  selector: 'app-getuser',
  templateUrl: './getuser.component.html',
  styleUrls: ['./getuser.component.css']
})
export class GetuserComponent extends HttpService {
  private _url: string = environment.BASE_URL + '/api/v1/users';
  userArray: any;
  loading:boolean = false;
  getList() {
    this.loading =true;
    return this.invokeService(this._url, '', 2);
   }


   ngOnInit() {
    this.getList().then( data => {
    this.userArray = data['data'].users;
    this.loading = false;
         });
   }

}

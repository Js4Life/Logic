import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import {FormsModule , FormControl} from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {HttpService} from './services/http.service';
import {FolderSvc} from './services/folder.service';
import {RoleSvc} from './services/role.service';
import {CreateSvc} from './services/createUser.service';
import { HttpModule } from '@angular/http';
import {routes} from './app.routes';
import { OperationComponent } from './operation/operation.component';
import {AppRouteConfig} from './app.router-config';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { ContextComponent } from './context/context.component';


import { FolderComponent } from './folder/folder.component';
import { RolesComponent } from './roles/roles.component';
import * as $ from 'jquery';

import { ClipboardModule } from 'ngx-clipboard';
import { GetuserComponent } from './getuser/getuser.component';
import { GoldenComponent } from './golden/golden.component';

import { ExportComponent } from './export/export.component';
import { LoadingModule , ANIMATION_TYPES} from 'ngx-loading';
import { UserManualComponent } from './user-manual/user-manual.component';

import { SimpleNotificationsModule } from 'angular2-notifications';
import { VocabsComponent } from './vocabs/vocabs.component';
import { CreateUserComponent } from './create-user/create-user.component';

// import {MatButtonModule, MatCheckboxModule} from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    OperationComponent,

    PageNotFoundComponent,
    ContextComponent,

    FolderComponent,
    RolesComponent,

    GetuserComponent,
    GoldenComponent,

    ExportComponent,
    UserManualComponent,
    VocabsComponent,
    CreateUserComponent
  ],
  imports: [
    BrowserModule,
    routes,
    HttpClientModule,
    FormsModule,
    HttpModule,
    ClipboardModule,
    LoadingModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      backdropBackgroundColour: 'rgba(0,0,0,0)',
      backdropBorderRadius: '4px',
      primaryColour: '#00fa01',
      secondaryColour: '#aeaea2',
      tertiaryColour: '#ffffff'
  }),
        BrowserAnimationsModule,
        SimpleNotificationsModule.forRoot()

  ],
  providers: [AppRouteConfig, HttpService, FolderSvc, RoleSvc , CreateSvc],
  bootstrap: [AppComponent]
})
export class AppModule { }

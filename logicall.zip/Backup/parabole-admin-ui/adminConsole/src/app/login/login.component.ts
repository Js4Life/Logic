import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AppRouteConfig} from '../app.router-config';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  formdata: any= {};
  errorMsg:any;
  login() {
    if (this.formdata.user == 'admin' && this.formdata.password == 'admin'){
        this.goTo.goToLogin('operation');
    } else {
     this.errorMsg = 'Invalid credentials';
    }
  }

  constructor(public router: Router, private goTo: AppRouteConfig) { }

  ngOnInit() {
  }

}

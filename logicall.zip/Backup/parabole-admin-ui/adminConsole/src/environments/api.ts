export const APIList = {

  AdminURLs: {
    CLEAN_DB: {
      url: "/api/v1/admin/cleanDB",
      description: "clean DB"
    },
    SAVE_CONTEXT: {
      url: "/api/v1/jenatdb/saveContextToDB",
      description: "Save Context"
    },
    SAVE_ALL_COMPONENTS: {
      url: "/api/v1/jenatdb/saveAllComponentToDB",
      description: "Save All Components"
    },
    SAVE_ALL_BUSSINESS_SEGMENTS: {
      url: "/api/v1/jenatdb/saveAllBusinessSegmentToDB",
      description: "Save All Bussiness Segments"
    },
    SAVE_PRODUCTS: {
      url: "/api/v1/jenatdb/saveAllProductToDB",
      description: "Save all products"
    },
    WORD_DICTIONARY: {
      url: "/api/v1/masterdata/wordDictionary",
      description: "get Word Dictionary"
    },
    KNOWLEDGE_TO_DB: {
      url: "/api/v1/jenatdb/saveKnowledgeToDB",
      description: "Knowledge to DB"
    },

    CREATE_FOLDER: {
      url: "/api/v1/docexplorer/folders",
      description: "Create Folder"
    },

    CREATE_ROLE: {
      url: "/api/v1/users/roles",
      description: "Create Role"
    },

    BUTTON_NAME: {
      name: "Initiate DB",
      description: "Trigger Init DB Button Label"
    },

    CREATE_USER : {
        url:"/api/v1/users/signUp",
        description : 'Create New User'
    }
  }


};

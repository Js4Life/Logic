// Sharepoint Proxy to avoid CORS while using SharePoint REST apis

var express = require('express');
var request = require('request');
var parseString = require('xml2js').parseString;
var bodyParser = require('body-parser');
var session = require('express-session') ;

var tokenReq = '<?xml version="1.0" encoding="utf-8"?>';
tokenReq += '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">';
tokenReq += '  <soap:Body>';
tokenReq += '    <GetUpdatedFormDigestInformation xmlns="http://schemas.microsoft.com/sharepoint/soap/" />';
tokenReq += '  </soap:Body>';
tokenReq += '</soap:Envelope>';


function login(req, res) {
    var sharepointSite = req.session.sharepointSite ;
    var username = req.body.username ;
    var password = req.body.password ;

    postData = '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing" xmlns:u="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"><s:Header><a:Action s:mustUnderstand="1">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action><a:ReplyTo><a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address></a:ReplyTo><a:To s:mustUnderstand="1">https://login.microsoftonline.com/extSTS.srf</a:To><o:Security s:mustUnderstand="1" xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"><o:UsernameToken>' +
        '<o:Username>' + username + '</o:Username>' +
        '<o:Password>' + password + ' < /o:Password>' +
    '</o:UsernameToken></o:Security></s:Header><s:Body><t:RequestSecurityToken xmlns:t="http://schemas.xmlsoap.org/ws/2005/02/trust"><wsp:AppliesTo xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"><a:EndpointReference>'
        + '<a:Address>' + sharepointSite + '</a:Address>' + '</a:EndpointReference></wsp:AppliesTo><t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType><t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType><t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType></t:RequestSecurityToken></s:Body></s:Envelope>';

    var authReq =   '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing" xmlns:u="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">';
    authReq +=      '  <s:Header>'
    authReq +=      '    <a:Action s:mustUnderstand="1">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action>';
    authReq +=      '    <a:ReplyTo>'
    authReq +=      '      <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>';
    authReq +=      '    </a:ReplyTo>'
    authReq +=      '    <a:To s:mustUnderstand="1">https://login.microsoftonline.com/extSTS.srf</a:To>';
    authReq +=      '    <o:Security s:mustUnderstand="1" xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">';
    authReq +=      '      <o:UsernameToken>'
    authReq +=      '        <o:Username>' + username + '</o:Username>'
    authReq +=      '        <o:Password>' + password + '</o:Password>'
    authReq +=      '      </o:UsernameToken>'
    authReq +=      '    </o:Security>'
    authReq +=      '  </s:Header>'
    authReq +=      '  <s:Body>'
    authReq +=      '    <t:RequestSecurityToken xmlns:t="http://schemas.xmlsoap.org/ws/2005/02/trust"><wsp:AppliesTo xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy">';
    authReq +=      '      <a:EndpointReference>'
    authReq +=      '        <a:Address>' + sharepointSite + '</a:Address>'
    authReq +=      '      </a:EndpointReference>'
    authReq +=      '      </wsp:AppliesTo>'
    authReq +=      '      <t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType>';
    authReq +=      '      <t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType>';
    authReq +=      '      <t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType>'
    authReq +=      '    </t:RequestSecurityToken>'
    authReq +=      '  </s:Body>'
    authReq +=      '</s:Envelope>'; 

    console.log ( "Getting Token for sharepoint site:" + req.session.sharepointSite ) ;
    request({
      headers: { "Access-Control-Allow-Origin": "*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36" 
                    },
      url: 'https://login.microsoftonline.com/extSTS.srf',
      contentType: 'application/soap+xml; charset=utf-8',
      body: authReq,
      method: 'POST'
    }, function (err, response, body) {
        parseString(body, function (err, result) {
            req.session.token = result['S:Envelope']['S:Body'][0]['wst:RequestSecurityTokenResponse'][0]['wst:RequestedSecurityToken'][0]['wsse:BinarySecurityToken'][0]['_'] ;
            console.log ( "Getting Token for sharepoint site:" + req.session.sharepointSite + " Successful") ;
            getFedAuthCookies(req, res ) ;
        });
    });
}


//https://pholpar.wordpress.com/2013/05/11/accessing-office-365-sharepoint-sites-using-rest-from-a-local-html-javascript-host/
function getFedAuthCookies(req, res)
{
    var loginUrl = req.session.sharepointSite + '/_forms/default.aspx?apr=1&wa=wsignin1.0' ;
    var j = request.jar() ;
    console.log ( "Signing for sharepoint site:" + req.session.sharepointSite + " With the token received") ;
     request = request.defaults({jar:j}) /*request = request.defaults({jar: true})*/
     request({
      headers: { "Access-Control-Allow-Origin": "*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36" 
                    },
      url: loginUrl,
      contentType: 'application/x-www-form-urlencoded',
      body: req.session.token,
      method: 'POST'
    }, function (err, response, body) {
        console.log ( "Signing for sharepoint site:" + req.session.sharepointSite + " Successful. Got Cookies.") ;
        // we will get a 302 but cookies must have been set
        cookieHeaders = response.headers['set-cookie']  ;
        cookies = [] ;
        for (var i = 0; i < cookieHeaders.length; i++) {
            var cookieReceived = cookieHeaders[i].split(",");
            var split = cookieReceived.toString().split(';') ;
            cookies.push( split[0]) ;
        }
        req.session.cookie_rtFa_FedAuth = cookies[0] + ";" + cookies[1] ;
        //refreshDigestViaWS() ;  // this works only in Browser but fails everywhere else
        refreshDigestViaREST(req, res) ;    // this works only in node.js/fiddler etc but not in browser
    });
}

function refreshDigestViaREST(req, res)
{
    console.log ( "Getting Digest for sharepoint site:" + req.session.sharepointSite ) ;
    request({
      headers: { "Access-Control-Allow-Origin": "*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
                    'Cookie': req.session.cookie_rtFa_FedAuth
                },
      url: req.session.sharepointSite + '/_api/contextinfo',
      contentType: 'text/plain',
      body: 'somejunk',
      method: 'POST'
    }, function (err, response, body) {
        console.log ( "Getting Digest for sharepoint site:" + req.session.sharepointSite + " Successful") ;
        console.log ( "Login for sharepoint site:" + req.session.sharepointSite + " Completed Successfully") ;
        parseString(body, function (err, result) {
            req.session.digest = result['d:GetContextWebInformation']['d:FormDigestValue'][0] ;
            //console.log ( req.session.digest ) ;
            req.session.save() ;
            //res.send("success") ;
            res.send ( JSON.stringify( {
                'cookie_rtFa_FedAuth': req.session.cookie_rtFa_FedAuth,
                'digest': req.session.digest
            })) ; 
        });
    });
}

function getSPSiteTitle(req, res, callback)
{
    request({
      headers: { "Access-Control-Allow-Origin": "*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
                    'Cookie': req.session.cookie_rtFa_FedAuth,
                    'X-RequestDigest': req.session.digest
                },
      url: req.session.sharepointSite + '/_api/web?$select=Title',
      method: 'GET'
    }, callback );
}

function getSharePointFolder(req, res )
{
    var folderPath = req.body.folderPath ;
    console.log ("getSharePointFolder( " + folderPath + ')' + " for site " + req.session.sharepointSite ) ;
    request({
      headers: { "Access-Control-Allow-Origin": "*",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
                    'Cookie': req.session.cookie_rtFa_FedAuth,
                    'X-RequestDigest': req.session.digest
                },
      url: req.session.sharepointSite + "/_api/Web/GetFolderByServerRelativeUrl('/" + folderPath + "')?$expand=Folders,Files",
      method: 'GET'
    }, 
    function (err, response, body) {
        console.log ("getSharePointFolder( " + folderPath + ')' + " for site " + req.session.sharepointSite + " Successful") ;
        res.send(body) ;
    });
}


function getSharePointFile(req, res )
{
    var filePath = req.body.filePath ;
    console.log ("getSharePointFile( " + filePath + ')' + ')' + " for site " + req.session.sharepointSite ) ;
    var fileUrl = req.session.sharepointSite + '/_layouts/download.aspx?SourceUrl=' + req.session.sharepointSite + '/' + encodeURI(filePath) ;
    
    request({
            headers: { "Access-Control-Allow-Origin": "*",
                            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36",
                            'Cookie': req.session.cookie_rtFa_FedAuth,
                            'X-RequestDigest': req.session.digest,
                            'binaryStringResponseBody': true,
                            'accept': 'application/json; odata=verbose'
                        },
            url: fileUrl,
            method: 'GET',
            contentType: 'application/json;odata=verbose',
            encoding: null

          }).pipe(res) ;
}

var app = express(); 

app.set('trust proxy', 1) // trust first proxy
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: true }
}))

app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(bodyParser.json());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "X-RequestDigest, Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.post('/login', function(req, res) { 
    req.session.sharepointSite = 'https://' + req.body.sitename + '.sharepoint.com' ;
    console.log ( "Performing Login for sharepoint site:" + req.session.sharepointSite) ;
    login(req, res) ;
});

app.post('/folder', function(req, res) { 
    req.session.sharepointSite = req.body.sharepointSite ;
    req.session.cookie_rtFa_FedAuth = req.body.param1 ;
    req.session.digest = req.body.param2 ;

    getSharePointFolder(req, res) ; 
});

app.post('/file', function(req, res) {

    req.session.sharepointSite = req.body.sharepointSite ;
    req.session.cookie_rtFa_FedAuth = req.body.param1 ;
    req.session.digest = req.body.param2 ;

    getSharePointFile( req, res) ;
    
});

app.listen(5555, function() {
  console.log('listening on port:5555');
});

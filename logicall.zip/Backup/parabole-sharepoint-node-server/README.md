This repo is for sharepoint node server

Running the node server:

1. cd src
2. Intall node and express if not installed already
3. npm install
4. node sharepointproxy.js
